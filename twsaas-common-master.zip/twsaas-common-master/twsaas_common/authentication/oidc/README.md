# JwkCache

A class to lookup and cache public keys for verifying JSON Web Tokens

#### Example Use

```python
import jwt
from jose import jwk
from rest_framework_jwt.settings import api_settings
from twsaas_common.oidc import JwkCache
from django.conf import settings


_jwk_cache = JwkCache(
    ('https://authentication-server-1.com', 'https://authentication-server-2.com')
)


def jwt_decode_handler(token):
    header = jwt.get_unverified_header(token)
    kid = header.get('kid')

    key = _jwk_cache.find_key(kid)

    if key is None:
        raise jwt.DecodeError("no key found")

    key = jwk.construct(key, api_settings.JWT_ALGORITHM)
    key = key.to_pem()

    return jwt.decode(
        token,
        key,
        api_settings.JWT_VERIFY,
        options={'verify_exp': api_settings.JWT_VERIFY_EXPIRATION, 'verify_aud': False},
        leeway=api_settings.JWT_LEEWAY,
        issuer=api_settings.JWT_ISSUER,
        algorithms=[api_settings.JWT_ALGORITHM],
    )
```
