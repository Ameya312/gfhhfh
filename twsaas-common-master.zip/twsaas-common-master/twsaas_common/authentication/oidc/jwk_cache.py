import json
from datetime import datetime, timedelta

import requests

from twsaas_common import tw_logging as logging

logger = logging.getLogger(__name__)


def retrieve_keys(auth_server):
    openid_config = json.loads(
        requests.get('{}/.well-known/openid-configuration'.format(auth_server)).text
    )
    return json.loads(requests.get(openid_config['jwks_uri']).text)['keys']


class JwkCache:
    """
    Manage a cache of JWT keys from cognito and oidc sources.
    """

    def __init__(self, authorization_servers):
        self.delay_period = timedelta(minutes=5)
        # initialize to before the prior delay period so we will be elligable to
        # load keys on the first authc attempt.
        self.time_of_last_key_load = datetime.now() - self.delay_period
        self.jwt_keys = {}
        self.authorization_servers = authorization_servers

    def find_key(self, kid):
        """
        Looks for key with id kid in the cache.  Returns None if kid is not found.
        """
        key = self.jwt_keys.get(kid)
        # Only perform reload of keys if it has been 5 minutes since the last reload
        # so that a bad token doesn't flood the key provider
        if (
            key is None
            and datetime.now() - self.time_of_last_key_load > self.delay_period
        ):
            self._reload_keys()
            key = self.jwt_keys.get(kid)
        return key

    def _reload_keys(self):
        logger.info("reloading jwt keys")
        tmp_keys = []
        for auth_server in self.authorization_servers:
            try:
                tmp_keys += retrieve_keys(auth_server)
            except Exception:
                logger.exception(
                    f"Error retrieving JWT signing keys from server {auth_server}"
                )

        self.time_of_last_key_load = datetime.now()
        self.jwt_keys = {key['kid']: key for key in tmp_keys}
