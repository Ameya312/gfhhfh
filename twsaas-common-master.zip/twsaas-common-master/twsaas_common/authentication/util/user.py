from django.conf import settings
from django.contrib.auth import get_user_model as django_get_user_model
from django.contrib.auth.models import Group
from django.db import transaction
from django.db.utils import IntegrityError

from twsaas_common import tw_logging as logging

from . import managed_local_import_from_string

LOG = logging.getLogger(__name__)

build_user_processor = managed_local_import_from_string(
    getattr(settings, 'TW_COMMON_BUILD_USER_PROCESSOR', None)
)
save_user_modifier = managed_local_import_from_string(
    getattr(settings, 'TW_COMMON_SAVE_USER_MODIFIER', None)
)


def get_user(userid):
    User = django_get_user_model()
    user = None
    # validate that the user id *is* a valida UUID value
    if isinstance(userid, str):
        try:
            user = User.objects.get_by_natural_key(userid)

        except User.DoesNotExist:
            user = None

    else:
        LOG.error(f'User ID {userid} is not an opaque string value')
        # userid is not a valid UUID string
        user = None

    return user


def transform_for_save(provided_user_data):
    User = django_get_user_model()

    user_data = {}

    # Groups cannot be passed directly to the model
    groups = provided_user_data['groups'] if 'groups' in provided_user_data else None

    # The following fields need to be renamed for the model:
    copy_fields = {
        # Username field needs to be converted to the application's model
        'userid': User.USERNAME_FIELD
    }
    for k, v in copy_fields.items():
        if k in provided_user_data:
            user_data[v] = provided_user_data[k]

    # An application using this tool that needs more data from the token
    # than is provided by default can use `build_user_processor` to
    # extract the data from the token data and insert it into the data
    # sent to the User Model. This is an entirely optional step.
    if build_user_processor:
        user_data = build_user_processor(user_data, provided_user_data)

    return (user_data, groups)


def save_user(userid, provided_user_data):
    # copy the user data so the structure can be modified without modifying
    # the incoming data set
    user_data, groups = transform_for_save(provided_user_data)

    User = django_get_user_model()

    try:
        with transaction.atomic():
            user = User.objects.create(**user_data)
            if groups:
                for g in Group.objects.filter(name__in=groups):
                    g.user_set.add(user)

            if save_user_modifier:
                save_user_modifier(user)

            user.save()
            LOG.debug('save_user created user for userid {}'.format(userid))

    except IntegrityError as e:
        # This is meant to handle concurrent cases where the DB fails
        # b/c another process got to it first.
        user = get_user(userid)

        # if for some reason the integrity error happened and the user
        # was *not* there then throw the Does Not Exist error, use
        # `raise...from` to link to the original exception
        if user is None:
            raise User.DoesNotExist('User {} does not exist'.format(userid)) from e

    return user
