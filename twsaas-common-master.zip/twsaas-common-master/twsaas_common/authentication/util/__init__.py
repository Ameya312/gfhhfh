from django.core.exceptions import ImproperlyConfigured
from rest_framework.settings import import_from_string

from twsaas_common import tw_logging as logging

LOG = logging.getLogger(__name__)


def local_import_from_string(*args, **kwargs):
    """
    Wrap Django Rest's `import_from_string` to give a better error message
    when things go wrong and ensure that subtle errors don't persist.
    """
    try:
        return import_from_string(*args, **kwargs)

    except ImportError as ex:
        raise ImproperlyConfigured from ex


def managed_local_import_from_string(value):
    """
    Simple wrapper around `local_import_from_string` for loading the string
    if and only if it's a value to perform the import on, making use for
    optional loadable configuration values easier.
    """
    if value:
        return local_import_from_string(value, '')
    else:
        return None
