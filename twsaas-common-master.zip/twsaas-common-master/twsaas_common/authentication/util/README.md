# twsaas_common.authentication.util

Miscellaneous tools used by the authentication system.

This module provides a few tools used by the authentication modules.
For the most part other systems do not need to be concerned about it;
however, if using the `twsaas_authentication.user_integration` functionality
or if wanting to use this functionality directly then there are some features
and configurations here to be aware of.

# Run-Time Imports

This module provides an interface for loading modules dynamically at run-time.
This is a wrapper around the Django/Rest Framework functionality for ease of
use and diagnostics.

## `twsaas_common.authentication.util.local_import_from_string`

This is a simple wrapper around the Django Rest Framework's `import_from_string`
so that using it does not crash the application, but provides a graceful resolution
and logs the issue.

## `twsaas_common.authentication.util.managed_local_import_from_string`

This is a wrapper around the `local_import_from_string` which primarily
handles the case of the string being invalid; useful for loading a string
based on a configuration setting.

# User Model Support: `twsaas_common.authentication.util.user`

This module provides some simply support around the User Model:

* `get_user`
* `save_user`

The `get_user` function relies on the Django User Model having the
USERNAME_FIELD configured. This field defaults to `username` if it is
not configured. As this is a Django User Model feature it may cause some
non-obvious errors if things are not configured properply.

The `save_user` function also has an important configuration value:

* `TW_COMMON_BUILD_USER_PROCESSOR`
* `TW_COMMON_SAVE_USER_MODIFIER`

## `TW_COMMON_BUILD_USER_PROCESSOR`

The Authentication Handlers convert the Token Payload into a
uniform, auth system agnostic format:

```python
    {
        'auth_source': "AuthSystemName",
        'userid': "<User Identifier UUID>",
        'groups': ["list", "of", "groups"],
        'status': "<User Status String>",
        'active': "Boolean: User Enabled/Disabled",
        'user_attributes': {
            "user": "attributes",
            "by": "key-value pairs",
        },
        'payload': {
            "dict": "original token payload"
        },
    }
```

The `save_user` function utilizes its own transformation function to
convert the uniform token payload into one acceptable for the models.
The transformation extracts the groups, userid, and active fields.

If the underlying model needs more information from the token payload
then the `TW_COMMON_BUILD_USER_PROCESSOR` parameter can be used to
specify a function to be called during the tranformation process. The
function will have access to the uniform token (see above) and the
user data being sent to the model. It's return value will be sent to
the user model:

###: Example: Build User Processor

```python
def application_build_user_processor(model_user_data, uniform_token_payload):
    user_data = {}
    user_data.update(model_user_data)
    user_data['foo'] = uniform_token_data['payload']['bar']
    user_data['userAttributes'] = {}
    for k, v in uniform_token_data['user_attributes']:
        if 'b33f' in k:
            user_data['userAttributes'][k] = v
    return user_data
```

## `TW_COMMON_SAVE_USER_MODIFIER`

By default, `save_user` will just store the user to the database.
However, some applications may wish to add more properties to the user
before doing so. For instance Scan Manager may add a `Subscription`
object to new users to enable trial services provided.

### Example: Save User Modifier

```python
def save_user_modifier(user):
    """
    Modify the user object as desired
    """
    user.set_unusable_password()
```

## Configuration

To use these tools add the following to the Django application's settings:

```python
TW_COMMON_SAVE_USER_MODIFIER = "myapplication.user_integraration.save_user_modifier"
TW_COMMON_BUILD_USER_PROCESSOR = "myapplication.user_integration.build_user_modifier"
```
