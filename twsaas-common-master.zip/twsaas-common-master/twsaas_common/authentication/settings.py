# Support for optional dependency: Django
django_settings_enabled = False
django_settings_enable_congnito = False
django_settings_enable_oidc = False
try:
    from django.conf import settings as django_settings

    django_settings_enabled = True

    # AWS Cognito Support requires the settings:
    #   FLAG_COGNITO_TOKENS
    #   FLAGS[django_settings.FLAG_COGNITO_TOKENS]
    #   AWS_REGION
    #   COGNITO_USER_POOL_ID
    #   The Cognito IDP URL is built using those parameters
    django_settings_enable_congnito = (
        hasattr(django_settings, 'FLAG_COGNITO_TOKENS')
        and hasattr(django_settings, 'FLAGS')
        and django_settings.FLAG_COGNITO_TOKENS in django_settings.FLAGS
        and django_settings.FLAGS[django_settings.FLAG_COGNITO_TOKENS]
        and hasattr(django_settings, 'AWS_REGION')
        and hasattr(django_settings, 'COGNITO_USER_POOL_ID')
    )

    # OIDC Support requires the settings:
    #   FLAG_OIDC_TOKENS
    #   FLAGS[django_settings.FLAG_OIDC_TOKENS]
    #   OIDC_BASE_URL
    #   The OIDC_BASE_URL is used if the flag enabled in the environment
    django_settings_enable_oidc = (
        hasattr(django_settings, 'FLAG_OIDC_TOKENS')
        and hasattr(django_settings, 'FLAGS')
        and django_settings.FLAG_OIDC_TOKENS in django_settings.FLAGS
        and django_settings.FLAGS[django_settings.FLAG_OIDC_TOKENS]
        and hasattr(django_settings, 'OIDC_BASE_URL')
    )
except ImportError:
    django_settings_enabled = False
