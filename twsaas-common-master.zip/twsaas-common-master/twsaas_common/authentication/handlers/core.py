from django.conf import settings
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext as _
from rest_framework import exceptions
from rest_framework_jwt.authentication import (
    JSONWebTokenAuthentication,
    jwt_get_username_from_payload,
)

from twsaas_common import tw_logging as logging
from twsaas_common.authentication import settings as auth_settings
from twsaas_common.authentication.util import managed_local_import_from_string
from twsaas_common.authentication.util import user as user_util

from .transformers import base as tranform_base
from .transformers import cognito, oidc

LOG = logging.getLogger(__name__)

INVALID_USER_CODE = _('invalid_user')
process_payload = managed_local_import_from_string(
    getattr(settings, 'JWT_PAYLOAD_PROCESSOR', None)
)


def unsupported_interface(payload):
    """
    Auth interface was not provided in the configuration.
    """
    raise ValidationError('unsupported auth system', code=INVALID_USER_CODE)


AUTH_MAPPING = {
    # Default Transformation for unverified token processing
    'default': tranform_base.transform_default,
    # AWS Cognito Transformation
    'cognito': cognito.transform_token,
    # OIDC Transformations
    'oidc': oidc.transform_token,
}
AUTH_STATUS_MAPPING = {
    # Skip Verification yields a default profile
    'default': settings.JWT_SKIP_VERIFY
    if hasattr(settings, "JWT_SKIP_VERIFY")
    else False,
    # AWS Cognito Status
    'cognito': auth_settings.django_settings_enable_congnito,
    # OIDC Status
    'oidc': auth_settings.django_settings_enable_oidc,
}


def authenticate_jwt_credentials(payload):
    """
    Returns an active user that matches the payload's username. If the user
    does not exist, it is created. If user is valid and authenticated,
    payload is optionally passed to a function defined in the
    JWT_PAYLOAD_PROCESSOR setting.
    """
    LOG.debug('authenticate_credentials payload {}'.format(payload))

    # Validate that the sub/username field exists in the payload
    # useful to do here since it applies to all
    sub = jwt_get_username_from_payload(payload)
    if not sub:
        msg = _('Invalid payload.')
        LOG.error(msg)
        raise exceptions.AuthenticationFailed(msg)

    try:
        LOG.debug(f"Authenticating with {payload['iss']}")
        userid = jwt_get_username_from_payload(payload)
        user = user_util.get_user(userid)
        if user is None:

            auth_service = (
                # map JWT_SKIP_VERIFY to `default`
                'default'
                if settings.JWT_SKIP_VERIFY
                else (
                    # if verifying the token, then process the ISS field
                    'cognito'
                    if 'cognito' in payload['iss']
                    else 'oidc'
                )
            )
            if not AUTH_STATUS_MAPPING[auth_service]:
                raise ValidationError(f'Auth Service {auth_service} is not allowed')

            LOG.debug(f'Authenticating Service: {auth_service}')

            transformed_payload = AUTH_MAPPING[auth_service](userid, payload)

            # These values are specific to the user record from Okta
            if transformed_payload.get('active') is not True:
                msg = 'User account {} is disabled.'.format(userid)
                raise ValidationError(msg, code=INVALID_USER_CODE)

            if transformed_payload.get('status') != 'CONFIRMED':
                msg = 'User account {} status is not CONFIRMED.'.format(userid)
                raise ValidationError(msg, code=INVALID_USER_CODE)

            user = user_util.save_user(userid, transformed_payload)

    except TypeError as e:
        LOG.error(f'Failed to authenticate user')
        raise exceptions.AuthenticationFailed(f'Failed to authenticate') from e

    except ValidationError as e:
        LOG.error(f"Validation Failed: {e}")
        raise exceptions.AuthenticationFailed(e.message) from e

    else:

        if not user.is_active:
            msg = 'User account {} is disabled.'.format(user)
            raise ValidationError(msg, code=INVALID_USER_CODE)

    if process_payload:
        process_payload(payload, user)

    return user


class CustomJSONWebTokenAuthentication(JSONWebTokenAuthentication):
    def authenticate_credentials(self, payload):
        """
        Returns an active user that matches the payload's username. If the user
        does not exist, it is created. If user is valid and authenticated,
        payload is optionally passed to a function defined in the
        JWT_PAYLOAD_PROCESSOR setting.
        """
        return authenticate_jwt_credentials(payload)
