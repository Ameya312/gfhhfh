"""
"""


class PayloadTransformer(object):
    def __init__(self, auth_source, userid, payload=None):
        self.auth_source = auth_source
        self.userid = userid
        self.roles = []
        self.groups = []
        self.status = ""
        self.active = False
        self.user_attributes = {}
        self.payload = payload if payload else {}

    def transform(self):
        return {
            'auth_source': self.auth_source,
            'userid': self.userid,
            'groups': self.groups,
            'status': self.status,
            'active': self.active,
            'user_attributes': self.user_attributes,
            'payload': self.payload,
        }


def transform_default(userid, ignore_payload):
    transformer = PayloadTransformer("BypassService", userid, payload={})
    transformer.active = True
    transformer.status = "CONFIRMED"
    transformer.user_attributes = {'email': 'nobody@nowhere.net'}
    return transformer.transform()
