"""
"""
from . import base


def transform_token(userid, input_payload):
    """
    Standard tool to convert an AWS Cognito JWT Token Payload and convert it to the
    standard payload format.
    """
    transformer = base.PayloadTransformer("Cognito", userid, payload=input_payload)
    transformer.groups = input_payload.get('cognito:groups', list())
    transformer.active = input_payload.get('Enabled', False)
    transformer.status = input_payload.get('UserStatus', "INVALID")
    for user_attribute in input_payload.get('UserAttributes', []):
        transformer.user_attributes[user_attribute['Name']] = user_attribute['Value']

    return transformer.transform()
