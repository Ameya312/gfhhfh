"""
"""
from . import base


def transform_token(userid, input_payload):
    transformer = base.PayloadTransformer("OIDC", userid, payload=input_payload)
    transformer.groups = input_payload.get('roles', list())
    transformer.active = True
    transformer.status = "CONFIRMED"
    return transformer.transform()
