```python3
transformed_payload = {
    'auth_source': <auth source>,               # string
    'userid': <userid>,                         # UUID stored in a string
    'roles': <list of roles>,                   # list
    'groups': <list of groups>,                 # list
    'status': <user status>,                    # string
    'active': <user enabled status>,            # boolean
    'user_attributes': <list of attributes>,    # list
}
```
