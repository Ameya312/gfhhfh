import boto3
from django.conf import settings
from rest_framework import exceptions
from rest_framework.authentication import BasicAuthentication

from twsaas_common import tw_logging as logging
from twsaas_common.authentication.jwt import jwt_decode_handler

from .core import authenticate_jwt_credentials

LOG = logging.getLogger(__name__)
client = boto3.client('cognito-idp', settings.AWS_REGION)


def idp_initiate_auth(userid, password):
    try:
        response = client.initiate_auth(
            AuthFlow='USER_PASSWORD_AUTH',
            ClientId=settings.APP_CLIENT_ID,
            AuthParameters={'USERNAME': userid, 'PASSWORD': password},
        )
        access_token = response['AuthenticationResult']['AccessToken']
        payload = jwt_decode_handler(access_token)
        user = authenticate_jwt_credentials(payload)
        return (user, None)
    except Exception as e:
        raise exceptions.AuthenticationFailed(str(e))


class BasicAuthCognitoBackend(BasicAuthentication):
    def authenticate_credentials(self, userid, password, request=None):
        return idp_initiate_auth(userid, password)
