# twsaas_common.authentication.handlers

Tooling for common Authentication Handlers.

This module provides support for the following authentication interfaces:

* Basic Authentication for AWS Cognito
* JSON Web Token Authentication

NOTE: Basic Authentication is only supported for AWS Cognito as it is not
something normally used and may be deprecated entirely in the future.

NOTE: AWS Cognito support requires `boto3` be available.

Both of these rely on an configuration provided infrastructure using the
following settings:

* `JWT_COGNITO_USER_PROCESSOR` - creates the user model for AWS Cognito users
* `JWT_OIDC_USER_PROCESSOR` - creates the user model for an OIDC provided users

Both of the above are expected to return an instance of the Django User Model
for their respective applications. The returned user model is then passed back
up the Django Authentication chain.

## Configuration

To use this module add the following to the application's settings:

```python
JWT_CONGITO_USER_PROCESSOR = "myapplication.user_integration.get_cognito_user"
JWT_OIDC_USER_PROCESSOR = "myapplication.user_integration.get_oidc_user"

REST_FRAMEWORK = {
    ...
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'twsaas_common.authentication.handlers.CustomJSONWebTokenAuthentication',
        'twsaas_common.authentication.handlers.cognito.BasicAuthCognitoBackend',
    ],
    ...
```

For information on how to build the interfaces referenced here see
`twsaas_common.authentication.user_integration`.
