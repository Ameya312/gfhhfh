import uuid
from datetime import datetime, timedelta

from rest_framework_jwt.settings import api_settings
from rest_framework_jwt.utils import jwt_encode_handler


def get_deterministic_uuid(tenant_id):
    return uuid.uuid5(uuid.NAMESPACE_URL, f'https://tripwire.io/tenant/{tenant_id}')


def get_okta_auth(tenant_id=3, roles=None, expiration=None, username=None):
    if isinstance(tenant_id, int):
        tenant_id = str(get_deterministic_uuid(tenant_id=tenant_id))
    if not roles:
        roles = []
    if not username:
        username = tenant_id
    expiration_delta = timedelta(seconds=300)
    payload = {
        'exp': datetime.utcnow() + expiration_delta,
        'roles': roles,
        'email': None,
        'username': username,
        'iss': 'https://login.tripwire.io/oauth2/default',
    }
    if tenant_id is not None:
        payload['tenant_id'] = tenant_id
    if expiration:
        payload['exp'] = expiration

    token = jwt_encode_handler(payload)
    return '{0} {1}'.format(api_settings.JWT_AUTH_HEADER_PREFIX, token)
