import datetime

import jwt
from jose import jwk

from twsaas_common import tw_logging as logging

from . import settings
from .oidc import JwkCache

LOG = logging.getLogger(__name__)
LOG.debug(f'Django Settings Enabled: {settings.django_settings_enabled}')

__add_auth_server_calls = 0
__jwk_cache_sources = []


class JwtDecodeHandler(object):
    """
    JSON Web Token Decoding Handler

    Provides functionality for decoding the JWT payload. Requires
    configuration before use.

    Configuration is provided on the instance which acts as a callable.
    JwtDecodeHandler is instantiated without any configuration options set.
    The configuration options are then set via the `set_jwt_options` method:

    .. code-block:: python

        jwt_handler = JwtDecodeHandler()
        ...
        jwt_handler.set_jwt_options(
            VerifyJwt,
            JwtExpiration,
            JwtLeeway,
            JwtIssuer,
            JwtAlgorithm
        )
        ...
        jwt_result = jwt_handler(encrypted_payload)
        ...

    The defaults used are taken from the Django Rest Framework's JWT Plugin, and
    adjusted for the Algorithm used (RS256 instead of HS256).
    """

    def __init__(
        self, verify=True, expiration=None, leeway=0, issuer=None, algorithm=None
    ):
        self.jwk_cache = JwkCache([])
        self.jwt_config = {
            'verify': verify,
            'expiration': expiration if expiration else datetime.timedelta(seconds=300),
            'leeway': leeway,
            'issuer': issuer,
            'algorithm': algorithm if algorithm else 'RS256',
        }

    def set_jwt_options(
        self, verify=None, expiration=None, leeway=None, issuer=None, algorithm=None
    ):
        if verify is not None:
            self.jwt_config['verify'] = verify
        if expiration is not None:
            self.jwt_config['expiration'] = expiration
        if leeway is not None:
            self.jwt_config['leeway'] = leeway
        if issuer is not None:
            self.jwt_config['issuer'] = issuer
        if algorithm is not None:
            self.jwt_config['algorithm'] = algorithm

    def add_authentication_server(self, server):
        self.jwk_cache.authorization_servers.append(server)

    def __call__(self, token):
        """
        Code is based on rest_framework_jwt.utils.jwt_decode_handler, the default
        handler. This was needed to allow us to use JWKs.
        """
        header = jwt.get_unverified_header(token)
        kid = header.get('kid')

        key = self.jwk_cache.find_key(kid)

        # If no key could be found, raise a DecodeError to our caller so it can translate
        # that to some form of 401...
        if key is None:
            raise jwt.DecodeError("no key found")

        key = jwk.construct(key, self.jwt_config['algorithm'])
        key = key.to_pem()

        return jwt.decode(
            token,
            key,
            self.jwt_config['verify'],
            options={'verify_exp': self.jwt_config['expiration'], 'verify_aud': False},
            leeway=self.jwt_config['leeway'],
            issuer=self.jwt_config['issuer'],
            algorithms=[self.jwt_config['algorithm']],
        )


jwt_decode_handler = JwtDecodeHandler(verify=True)
jwt_decode_debug_handler = JwtDecodeHandler(verify=False)


def setup_authorization_servers(servers, debug=True, production=True):
    # The following is primarily for testing and proving this was called.
    # For some reason mocking this call isn't working well. It's relatively
    # harmless to do this.
    global __add_auth_server_calls
    __add_auth_server_calls += 1

    for server in servers:
        if production:
            jwt_decode_handler.add_authentication_server(server)
        if debug:
            jwt_decode_debug_handler.add_authentication_server(server)


def setup_encryption_algorithm(algorithm=None, debug=True, production=True):
    # The following is primarily for testing purposes where the standard RS256
    # algorithm isn't viable for at least some downstream projects
    if algorithm is None:
        algorithm = 'RS256'
    if production:
        jwt_decode_handler.set_jwt_options(algorithm=algorithm)
    if debug:
        jwt_decode_debug_handler.set_jwt_options(algorithm=algorithm)


def jwt_username_handler(payload):
    # cognito provides this in the token as both sub and username. oidc provides it as
    # both uid and sub...
    return payload['sub']


# If the optional Django tooling is available then add those values
if settings.django_settings_enabled:
    LOG.debug(
        'Django Settings Enabled - attempting Authentication Server configuration'
    )
    # If there are AWS Cognito related configuration values in the Django Settings the
    # configure Cognito as a source
    if settings.django_settings_enable_congnito:
        LOG.debug(
            f'Adding AWS Cognito Support: {settings.django_settings.AWS_REGION} - {settings.django_settings.COGNITO_USER_POOL_ID}'
        )
        __jwk_cache_sources.append(
            f'https://cognito-idp.{settings.django_settings.AWS_REGION}.amazonaws.com/{settings.django_settings.COGNITO_USER_POOL_ID}'
        )

    # If there is an OIDC related setting, then configure OIDC as a source
    if settings.django_settings_enable_oidc:
        LOG.debug(f'Adding OIDC Support: {settings.django_settings.OIDC_BASE_URL}')
        __jwk_cache_sources.append(settings.django_settings.OIDC_BASE_URL)

    # If there is something in the list, then add it
    if __jwk_cache_sources:
        LOG.debug(f'Adding Authentication Servers: {__jwk_cache_sources}')
        # be explicit in the debug/production settings in case the defaults change
        setup_authorization_servers(__jwk_cache_sources, debug=True, production=True)


def get_django_settings():
    """
    Utility for retrieving state of current settings, namely for unit tests
    """
    return {
        'enabled': settings.django_settings_enabled,
        'oidc_enabled': settings.django_settings_enable_oidc,
        'cognito_enabled': settings.django_settings_enable_congnito,
        'jwk_cache': __jwk_cache_sources,
        'add_auth_server_calls': __add_auth_server_calls,
    }
