# twsaas_common.authentication

Support for common authentication functionality.

The Authentication Module provides support for the following means of authentication:

* JSON Web Tokens (JWT) via PyJWT

## Optional: Django Support

Support for Django is provided as an optional dependency. This support provides for
automatic configuration of the Authorization servers and is provided for the following
providers:

* AWS Cognito
* OIDC Providers (f.e Okta)

More information is below on how to configure Django applications for these providers.

There are also some integrations for various authentication methods available for
Django users:

* JWT Token Autnentication Support
* HTTP Basic Authentication Support

For more see [Authentication Handlers README](handlers/README.md).

## JWT Support

JWT Support is provided via the JwtDecodeHandler object. An instance of the object acts
as a callable object with its own parameter being the encrypted JWT Token.

### Configuring the JWT Decoding Handler

The JwtDecodeHandler is configurable via two methods: instance initialization, and the
`set_jwt_options()` method. Both take the same set of optional parameters, and a reasonable
set of defaults have been selected so that the `set_jwt_options()` method should not
be necessary to call.

The following configuration options are provided:

* verify
* expiration
* leeway
* issuer
* algorithm

In addition to these parameter driven configurations, the authentication servers will
need to be configured via the `add_authentication_server()` method. More information
on this is provided below.

#### Configuration Option: verify

This boolean parameter specifies whether or not to verify the JWT payload. By default
all payloads are verified. For certain environments (f.e local testing) it may be
useful to disable verification.

#### Configuration Option: expiration

This `datetime.timedelta` parameter determines if the token expiration is to be
honored. By default, this is 300 seconds (5 minutes).

NOTE: This might really be a simply boolean value; thereby anything that does not
evaluate to False may simply enforce that the expiration time is honored.

#### Configuration Option: leeway

This integral value determines how long after a token has expired that it may be treated
as unexpired. This is useful for situations when processing may take the token past its
expiration time. The default is 0.

#### Configuration Option: issuer

This string value determines if an JWT Issuer is accepted. If the value does not match the
token's `iss` claim then the `jwt.InvalidIssuerError` exception will be raised. By default
this is `None` and thereby accepting all issuers.

#### Configuration Option: algorithm

This string value determines the encryption algorithm used for decoding the encrypted
JWT payloads. The PyJWT library uses HS256 has its default value; however, this implementation
uses the Tripwire RS256 instead to minimize the need to configure the default decoder
objects provided.

### Provided Instances of JwtDecodeHandler

For convenience, and in part a salute to the Django usage, two default instances of the
JwtDecodeHandler are provided:

* `jwt_decode_handler`
* `jwt_decode_debug_handler`

The sole difference is that the `jwt_decode_debug_handler` defaults to having its
`verify` parameter set to `False`.

These are provided to make it easy to use the handler directly from frameworks like
Django that require a callable be provided in the application configuration.

#### Example: Django Configuration
```python
JWT_VERIFY = True
JWT_AUTH = {
    ...
    'JWT_DECODE_HANDLER': (
        'twsaas_common.authenticator.jwt.jwt_decode_handler' if JWT_VERIFY
        else 'twsaas_common.authenticator.jwt.jwt_decode_debug_handler'
    ),
    ...
}
```

#### Configuration Option: Authorization Server

JWT Authentication requires that the JWT Payload be authenticated against a known service
provider. The method of which is dependent on the encryption algorithm used. With the RS-family
of encryption algorithms a shared key is required to perform the validation and decryption.
To specify the authentication server keys to the JwtDecodeHandler the `add_authentication_server`
method is used.

For convenience, a helper function is provided for configurating the provided instances of the
JwtDecodeHandler - `setup_authorization_servers()`. This allows the caller to specify a
iterable containing the list of servers to configure and even some capability to control
which of the instances receives the configuration.

Additionally, and in part a salute to the Django usage, support to auto-configure the
authorization servers for the provided instances of the JwtDecodeHandler is provided for
applications with the appropriate dependencies installed. Auto-configuration is provided
for the following authorization servers:

* (Django) AWS Cognito
* (Django) OIDC Provider (e.g Okta)

More information on the auto-configuration support is provided below.

##### Optional: (Django) AWS Cognito Support

AWS Cognito Support is provided if the appropriate settings are part of the application's
Django settings. The following settings are required to make it available:

* `FLAG_COGNITO_TOKENS`
* `FLAGS[FLAG_COGNITO_TOKENS]`
* `AWS_REGION`
* `COGNITO_USER_POOL_ID`

###### Example (Django) AWS Cognito Support:
```python
FLAG_COGNITO_TOKENS = 'aws_cognito_tokens'
FLAGS = {
    ...
    # Enable support for AWS Cognito Tokens
    FLAG_COGNITO_TOKENS: TESTING,
    ...
}
...
AWS_REGION = os.environ.get('AWS_REGION', 'us-west-2')
COGNITO_USER_POOL_ID = os.environ.get('COGNITO_USER_POOL_ID')
```

##### (Django) Optional: OIDC Support

OIDC Support is provided if the appropriate settings are part of the application's
Django settings. The following settings are required to make it available:

* `FLAG_OIDC_TOKENS`
* `FLAGS[FLAG_OIDC_TOKENS]`
* `OIDC_BASE_URL`

###### Example (Django) OIDC Support:
```python
FLAG_OIDC_TOKENS = 'oidc_tokens'
FLAGS = {
    ...
    # Enable support for OIDC Tokens
    FLAG_OIDC_TOKENS: TESTING,
    ...
}
...
OIDC_BASE_URL = os.environ.get(
    'OIDC_BASE_URL', 'https://tripwire.oktapreview.com/oauth2/default'
)
```

###### (Django) OIDC Authentication in Unit Tests:

You must add the following settings to your django test settings for
authentication to work properly using the generated OIDC tokens.

```python
JWT_SKIP_VERIFY = os.getenv('JWT_SKIP_VERIFY') is not None

JWT_AUTH = {
    'JWT_AUTH_HEADER_PREFIX': 'Bearer',
    'JWT_ALGORITHM': 'HS256',
    'JWT_VERIFY': not JWT_SKIP_VERIFY,
}
```

Use `test_utils.get_okta_auth` to generate an OIDC token to pass into
the HTTP_AUTHORIZATION header of your test client requests.

```python
response = client.get(
    url,
    HTTP_AUTHORIZATION=get_okta_auth(tenant_id='1f5a36f4-192d-4641-8c4c-c59a36f69fae', username='chris')
)
```

tenant_id can also be passed in as a number to make a deterministic UUID
which can be convenient for testing.
