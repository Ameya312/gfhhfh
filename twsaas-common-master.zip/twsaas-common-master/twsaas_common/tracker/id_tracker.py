import uuid

import twsaas_common.tracker as tracker


def generate_uuid():
    return str(uuid.uuid4())


def get_client_correlation_id(request):
    return request.META.get('HTTP_X_CLIENT_CORRELATION_ID', None)


def set_client_correlation_id():
    tracker.context.client_correlation_id = generate_uuid()


def set_server_transaction_id():
    tracker.context.server_transaction_id = generate_uuid()
