import datetime
import os
import threading


class TrackerContext(threading.local):
    def __init__(self):
        self.reset()

    def reset(self):
        for attr in list(self.__dict__.keys()):
            delattr(self, attr)
        self.service_name = os.environ.get('SERVICE_NAME', None)
        self.container_id = os.environ.get('HOSTNAME', None)
        self.client_correlation_id = None
        self.server_transaction_id = None
        self.user = None
        self.sender = None
        self.start_time = None
        self.end_time = None
        self.tenant_id = None
        self.sequence = 0


context = TrackerContext()


def initialize_tracker():
    context.reset()
    context.start_time = datetime.datetime.utcnow()


def reset_tracker():
    context.reset()
