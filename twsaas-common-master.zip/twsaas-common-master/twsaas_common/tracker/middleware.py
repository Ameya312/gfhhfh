import datetime

import twsaas_common.tracker as tracker
from twsaas_common.tracker import initialize_tracker, reset_tracker
from twsaas_common.tracker.utils import set_request_data_to_storage


class IdTrackerMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        initialize_tracker()
        set_request_data_to_storage(request)
        response = self.get_response(request)
        tracker.context.end_time = datetime.datetime.utcnow()
        reset_tracker()
        return response
