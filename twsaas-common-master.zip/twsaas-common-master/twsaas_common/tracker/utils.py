import jwt
from jwt.exceptions import PyJWTError

import twsaas_common.tracker as tracker
from twsaas_common import tw_logging as logging
from twsaas_common.tracker import initialize_tracker
from twsaas_common.tracker.id_tracker import (
    get_client_correlation_id,
    set_client_correlation_id,
    set_server_transaction_id,
)

logger = logging.getLogger(__name__)


def get_request_custom_headers(request):
    """
    Get the headers values from the request Meta
    :param request:
    :return:
    """
    client_correlation_id = get_client_correlation_id(request)
    user = request.META.get('HTTP_X_USER', None)
    sender = request.META.get('HTTP_X_SENDER', None)
    return client_correlation_id, user, sender


def set_request_data_to_storage(request=None):
    """
    Populate the values like client_correlation_id, server_transaction_id etc..
    in the thread local storage.
    :param request:
    :return:
    """
    thread_req_log_entry = tracker.context
    thread_req_log_entry.client_correlation_id, thread_req_log_entry.user, thread_req_log_entry.sender = (
        None,
        None,
        None,
    )
    if request:
        thread_req_log_entry.client_correlation_id, thread_req_log_entry.user, thread_req_log_entry.sender = get_request_custom_headers(
            request
        )
        thread_req_log_entry.tenant_id, thread_req_log_entry.user = get_authentication_information(
            request
        )
    if thread_req_log_entry.client_correlation_id is None:
        set_client_correlation_id()
    set_server_transaction_id()


def init_tracker(func):
    def decorated(*args, **kwargs):
        initialize_tracker()
        set_request_data_to_storage()
        return func(*args, **kwargs)

    return decorated


def init_tracker_http_req(func):
    def decorated(request, *args, **kwargs):
        initialize_tracker()
        set_request_data_to_storage(request)
        return func(request, *args, **kwargs)

    return decorated


def get_authentication_information(request):
    """
    Fetches the jwt token from the authorization header and
    returns the tenant id and user id
    """
    try:
        auth_header = request.META.get('Authorization')
        if not auth_header:
            auth_header = request.META.get('HTTP_AUTHORIZATION')
        if auth_header and auth_header.startswith('Bearer'):
            payload = jwt.decode(auth_header.split()[1], verify=False)
            return payload.get('tenant_id'), payload.get('sub')
    except PyJWTError as e:
        logger.exception(
            'Error decoding jwt token. Setting tenantId and userId as None. {exception}'.format(
                exception=str(e)
            )
        )

    return None, None
