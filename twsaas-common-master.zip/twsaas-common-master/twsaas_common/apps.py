from django.apps import AppConfig


class TwsaasCommonConfig(AppConfig):
    name = 'twsaas_common'
