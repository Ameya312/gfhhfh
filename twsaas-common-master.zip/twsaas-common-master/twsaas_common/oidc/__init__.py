# Moving this functionality to a new location, maintaining
# this location for compatibility only until things can migrate
import warnings

from ..authentication.oidc.jwk_cache import JwkCache

warnings.warn(
    "This module location depreated. Please import from "
    "twsaas_common.authentication.oidc instead.",
    DeprecationWarning,
)

__all__ = ['JwkCache']
