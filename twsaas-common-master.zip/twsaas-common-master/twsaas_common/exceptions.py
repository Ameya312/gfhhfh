class TwSaasCommonException(Exception):
    pass


class MessageTooLargeException(TwSaasCommonException):
    pass
