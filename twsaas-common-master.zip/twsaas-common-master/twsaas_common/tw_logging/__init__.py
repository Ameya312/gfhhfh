import logging

import twsaas_common.tracker as tracker


class TwLogAdapter(logging.LoggerAdapter):
    def __init__(self, logger, extra):
        """
        Initialize the adapter with a logger and a dict-like object which
        provides contextual information. This constructor signature allows
        easy stacking of LoggerAdapters, if so desired.

        You can effectively pass keyword arguments as shown in the
        following example:

        adapter = TwLogAdapter(someLogger, dict(p1=v1, p2="v2"))
        """
        self.logger = logger
        self.extra = extra if extra else {}
        super().__init__(self.logger, self.extra)

    def process(self, msg, kwargs):
        """
        Process the logging message and keyword arguments passed in to
        a logging call to insert contextual information. You can either
        manipulate the message itself, the keyword args or both. Return
        the message and kwargs modified (or not) to suit your needs.
        """
        if kwargs.get("extra", None) is None:
            kwargs["extra"] = {}
        if kwargs["extra"]:
            data = dict(
                (k, v) for k, v in self.extra.items() if k not in kwargs["extra"]
            )
            kwargs["extra"].update(data)
        elif self.extra:
            kwargs["extra"].update(self.extra)
        kwargs["extra"].update(vars(tracker.context))
        return msg, kwargs


def getLogger(name, extra=None):
    log_adapter = TwLogAdapter(logging.getLogger(name), extra)
    return log_adapter
