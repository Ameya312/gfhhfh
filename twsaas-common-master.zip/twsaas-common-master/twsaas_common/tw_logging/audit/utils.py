from django.db import models
from django.db.models import ForeignKey, ManyToManyField

from twsaas_common import tw_logging as logging

logger = logging.getLogger(__name__)


def value_or_redact(name, value, redaction_list):
    if name in redaction_list:
        return 'redacted'
    return value


def get_updated_fields(existing_data, updated_data, fields_to_redact):
    """
    This function take old and new dictionary and compare the new value with the old value, if the value is changed
    then it will create a new dict of changed value and return which contains the old and new value of that key.
    :param existing_data:
    :param updated_data:
    :return: sample output:
    {
      "column_name": {
        "old_value": "original value",
        "new_value": "new value"
      },
      "redacted_column": {
        "old_value": "redacted",
        "new_value": "redacted"
      }
    }
    """
    # No updates, directly apply the redaction when processing the audit
    if not updated_data:
        return {
            k: {
                "old_value": value_or_redact(
                    k, check_datatype_and_model_to_dict(v), fields_to_redact
                ),
                "new_value": value_or_redact(k, None, fields_to_redact),
            }
            for (k, v) in existing_data.items()
        }

    # updates involved
    updated_fields_audit = {}
    for updated_k, updated_v in updated_data.items():
        if updated_v:
            old_v = existing_data.get(updated_k)
            if updated_k not in updated_fields_audit:
                updated_fields_audit[updated_k] = {
                    "old_value": old_v,
                    "new_value": None,
                }
            if type(updated_v) in [list, set, tuple]:
                new_updated_values = check_datatype_and_model_to_dict(updated_v)
                diff_updated_values = [
                    new_updated_value
                    for new_updated_value in new_updated_values
                    if old_v and new_updated_value not in old_v
                ]
                if (
                    not diff_updated_values
                    and old_v
                    and len(new_updated_values) == len(old_v)
                ):
                    updated_fields_audit[updated_k]["old_value"] = []
                    updated_fields_audit[updated_k]["old_value"] = type(updated_v)(
                        updated_fields_audit[updated_k]["old_value"]
                    )
                    updated_v = type(updated_v)(diff_updated_values)
                else:
                    updated_v = type(updated_v)(new_updated_values)
            else:
                updated_v = check_datatype_and_model_to_dict(updated_v)
            updated_fields_audit[updated_k]["new_value"] = updated_v

            # Only report changing fields
            if (
                updated_fields_audit[updated_k]["new_value"]
                == updated_fields_audit[updated_k]["old_value"]
            ):
                # drop any that didn't change
                updated_fields_audit.pop(updated_k, None)

            # Apply Redaction Logic
            elif updated_k in fields_to_redact:
                updated_fields_audit[updated_k]['new_value'] = "redacted"
                updated_fields_audit[updated_k]['old_value'] = "redacted"

    return updated_fields_audit


def check_datatype_and_model_to_dict(value):
    if type(value) in [list, set, tuple]:
        new_updated_values = []
        for data in value:
            new_updated_values.append(check_datatype_and_model_to_dict(data))
        value = new_updated_values
    elif isinstance(value, models.Model):
        return model_to_dict(value)
    return value


def model_to_dict(db_instance):
    """
    This will convert any model instance to dict, if instance contains ManyToManyField or ForeignKey then it will
    convert those as well into dict with all its attributes as a key.
    :param db_instance: model instance
    :return: dict
    """
    opts = db_instance._meta
    data = {}
    for f in opts.concrete_fields + opts.many_to_many:
        if isinstance(f, ManyToManyField):
            if db_instance.pk is None:
                data[f.name] = []
            else:
                data[f.name] = [
                    model_to_dict(i) for i in f.value_from_object(db_instance)
                ]
        elif isinstance(f, ForeignKey):
            if f.value_from_object(db_instance) is not None:
                data[f.name] = model_to_dict(getattr(db_instance, f.name))
            else:
                data[f.name] = None
        else:
            data[f.name] = f.value_from_object(db_instance)
    return data


def audit_updated_fields(fields_to_redact=None):
    if fields_to_redact is None:
        fields_to_redact = []

    def wrapped(func):
        def decorated(self, serializer):
            try:
                instance_dict_data = {}
                if self.action in ('update', 'partial_update'):
                    old_obj = self.get_object()
                    instance_dict_data = model_to_dict(old_obj)
                new_data_dict = serializer.validated_data
                self.updated_fields = get_updated_fields(
                    instance_dict_data, new_data_dict, fields_to_redact=fields_to_redact
                )
            except Exception as e:
                logger.exception(
                    "Exception while finding the updated fields {0}".format(str(e))
                )
            return func(self, serializer)

        return decorated

    return wrapped
