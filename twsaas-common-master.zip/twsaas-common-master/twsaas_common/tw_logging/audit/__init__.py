import logging

import twsaas_common.tracker as tracker
from twsaas_common.tw_logging import TwLogAdapter


class TwAuditLogAdapter(TwLogAdapter):
    AUDIT = 25

    def __init__(self, logger, extra):
        """
        Initialize the adapter with a logger and a dict-like object which
        provides contextual information. This constructor signature allows
        easy stacking of LoggerAdapters, if so desired.

        You can effectively pass keyword arguments as shown in the
        following example:

        adapter = TwAuditLogAdapter(someLogger, dict(p1=v1, p2="v2"))
        """
        logging.addLevelName(self.AUDIT, "AUDIT")
        self.logger = logger
        self.extra = extra if extra else {}
        super().__init__(self.logger, self.extra)

    def process(self, msg, kwargs):
        tracker.context.sequence += 1
        return super().process(msg, kwargs)

    def audit(
        self,
        msg,
        resource=None,
        resource_type=None,
        action=None,
        uri=None,
        method=None,
        status_code=None,
        updated_fields=None,
        *args,
        **kwargs,
    ):
        """
        Delegate a audit call to the underlying logger.
        """
        kwargs.update(
            {
                "extra": {
                    "resource": resource,
                    "resource_type": resource_type,
                    "action": action,
                    "uri": uri,
                    "method": method,
                    "status_code": status_code,
                    "updated_fields": updated_fields,
                }
            }
        )
        self.log(self.AUDIT, msg, *args, **kwargs)


def getAuditLog(extra=None):
    log_adapter = TwAuditLogAdapter(logging.getLogger("audit"), extra)
    return log_adapter
