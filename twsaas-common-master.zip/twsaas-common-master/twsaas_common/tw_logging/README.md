# TwLogger

TW custom logging framework which extends the standard python logging module and provides logs in json format.

## Features of TwLogger

- TW logger module extends standard python logger module and inherits all the existing features of standard logging module.
- This will reduce the boiler plate code for developer while logging.

### Twlogger use(standalone)

#### In Django project:

- Add the logger settings in settings.py as below,

```python
import sys

LOGGING = {
    'version': 1,
    'disable_existing_loggers': True,
    'formatters': {'json': {
        '()': 'twsaas_common.tw_logging.log_formatter.JSONFormatter'
    }},
    'filters': {
        'sanitizer': {
            '()': 'twsaas_common.tw_logging.filter.LogSanitizer'
            'patterns': [
                # Extra patterns to redact go here
            ]
        }
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'stream': sys.stdout,
            'formatter': 'json',
            'filters': ['sanitizer'],
        }
    },
    'loggers': {
        '': {'handlers': ['console'], 'level': 'DEBUG', 'propagate': True},
        'django': {'handlers': ['console'], 'propagate': True, 'level': 'INFO'},
        'django.request': {'handlers': ['console'], 'propagate': False, 'level': 'INFO'},
    },
}
```

- Sample logging usage:

```python
from twsaas_common import tw_logging as logging
logger = logging.getLogger(__name__)

def ping(request):
    logger.info('Scan Started', extra={'scan_Id': 'r564dewc52d6ce'})
```
sample log output:

```json
{"scan_Id": "r564dewc52d6ce", "log_level": "INFO", "time": "2019-08-13T10:12:40.041398", "message": "Scan Started"}
{"server_time": "13/Aug/2019 09:45:47", "status_code": 200, "log_level": "INFO", "time": "2019-08-13T09:45:47.892707", "message": "\"GET /ping/ HTTP/1.1\" 200 4"}
```


#### Steps to enable it in any standard python file

```python
import sys
import logging.config

from twsaas_common import tw_logging

LOG_CONFIG = {
    'version': 1,
    'disable_existing_loggers': True,
    'formatters': {'json': {
        '()': 'twsaas_common.tw_logging.log_formatter.JSONFormatter'
    }},
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'stream': sys.stdout,
            'formatter': 'json',
        }
    },
    'loggers': {
        '': {'handlers': ['console'], 'level': 'DEBUG', 'propagate': True},
        'django': {'handlers': ['console'], 'propagate': True, 'level': 'INFO'},
        'django.request': {'handlers': ['console'], 'propagate': False, 'level': 'INFO'},
        'test': {'handlers': ['console'], 'propagate': False, 'level': 'INFO'},
    },
}

logging.config.dictConfig(LOG_CONFIG)
logger = tw_logging.getLogger('test')

logger.info('Scan Started', extra={'scan_Id': 'r564dewc52d6ce'})


def test():
    try:
        raise ValueError('something wrong')
    except ValueError:
        logger.error('Request failed', exc_info=True, extra={'scan_Id': 'r564dewc52d6ce'})


if __name__ == "__main__":
    test()

```

Example output log in file log.json:

```json
{"scan_Id": "r564dewc52d6ce", "log_level": "INFO", "time": "2019-08-13T10:12:40.041398", "message": "Scan Started"}
{"log_level": "ERROR", "time": "2019-08-13T10:12:40.041919", "exc_info": "Traceback (most recent call last):\n  File \"/sample-rest-service/src/sample_rest_service/rest_api/test.py\", line 16, in <module>\n    raise ValueError('something wrong')\nValueError: something wrong", "message": "Request failed"}

```

## TwLogger with Tracker module 

Developer can use tracker module (https://github.scm.tripwire.com/tw-devops/twsaas-common/tree/master/twsaas_common/tracker) with this module so that they don't have to worry about extra stuff (like client correlation id, service transaction id, service name etc.) which can be part of extra logging information.

#### In Django Project: 

- Add below custom middleware in settings.py as a first Middleware.

```python
  MIDDLEWARE = [
    'twsaas_common.tracker.middleware.IdTrackerMiddleware',
    ....
    ....
    ]
````
- Add the logger settings in settings.py as below,

```python
import sys

LOGGING = {
    'version': 1,
    'disable_existing_loggers': True,
    'formatters': {'json': {
        '()': 'twsaas_common.tw_logging.log_formatter.JSONFormatter'
    }},
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'stream': sys.stdout,
            'formatter': 'json',
        }
    },
    'loggers': {
        '': {'handlers': ['console'], 'level': 'DEBUG', 'propagate': True},
        'django': {'handlers': ['console'], 'propagate': True, 'level': 'INFO'},
        'django.request': {'handlers': ['console'], 'propagate': False, 'level': 'INFO'},
    },
}
```

- Now do the following to log any messages in any file,

```python
from twsaas_common import tw_logging as logging

logger = logging.getLogger('rest_api', extra={})

def ping(request):
    logger.info('Scan Started', extra={'scan_Id': 'r564dewc52d6ce'})
```
Example output log will be as below,

```json
{"scan_Id": "r564dewc52d6ce", "_service_name": "sample_rest_service", "_container_id": null, "client_correlation_id": "28747503-243e-4a34-a5f6-87430dbc9288", "server_transaction_id": "b0b634e0-7c34-4bd6-b1a1-a3732bfce925", "user": null, "sender": null, "start_time": "2019-08-13T11:11:26.377140", "end_time": null, "log_level": "INFO", "time": "2019-08-13T11:11:26.491633", "message": "Scan Started"}
{"server_time": "13/Aug/2019 11:11:26", "status_code": 200, "log_level": "INFO", "time": "2019-08-13T11:11:26.492625", "message": "\"GET /ping/ HTTP/1.1\" 200 4"}
```

#### Steps to enable it in any standard python file:

```python
import sys
import logging.config

from twsaas_common import tw_logging
from twsaas_common.tracker.utils import init_tracker

LOG_CONFIG = {
    'version': 1,
    'disable_existing_loggers': True,
    'formatters': {'json': {
        '()': 'twsaas_common.tw_logging.log_formatter.JSONFormatter'
    }},
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'stream': sys.stdout,
            'formatter': 'json',
        }
    },
    'loggers': {
        '': {'handlers': ['console'], 'level': 'DEBUG', 'propagate': True},
        'django': {'handlers': ['console'], 'propagate': True, 'level': 'INFO'},
        'django.request': {'handlers': ['console'], 'propagate': False, 'level': 'INFO'},
        'test': {'handlers': ['console'], 'propagate': False, 'level': 'INFO'},
    },
}

logging.config.dictConfig(LOG_CONFIG)
logger_adapter = tw_logging.getLogger('test', extra={})

logger_adapter.info('Scan Started', extra={'scan_Id': 'r564dewc52d6ce'})


@init_tracker
def test():
    try:
        raise ValueError('something wrong')
    except ValueError:
        logger_adapter.error('Request failed', exc_info=True, extra={'scan_Id': 'r564dewc52d6ce'})


if __name__ == "__main__":
    test()

```

Example output log in file log.json:

```json
{"scan_Id": "r564dewc52d6ce", "log_level": "INFO", "time": "2019-08-20T13:27:51.654641", "message": "Scan Started"}
{"scan_Id": "r564dewc52d6ce", "_service_name": null, "_container_id": null, "client_correlation_id": "80d079de-d689-449e-9dbb-3776decd5d83", "server_transaction_id": "313e5707-a160-48d3-aafa-7356d8db819b", "user": null, "sender": null, "start_time": "2019-08-20T13:27:51.655506", "end_time": null, "log_level": "ERROR", "time": "2019-08-20T13:27:51.655877", "exc_info": "Traceback (most recent call last):\n  File \"/home/nfs/<username>/projects/sample-rest-service/src/sample_rest_service/rest_api/management/test.py\", line 36, in test\n    raise ValueError('something wrong')\nValueError: something wrong", "message": "Request failed"}

```


## Audit logging 
A new log level i.e. `audit` is  defined for audit purpose. Perform the following steps to use the audit logging functionality in your project.

#### In Django Project: 

- Add below custom middleware in settings.py as a first Middleware.

```python
  MIDDLEWARE = [
    'twsaas_common.tracker.middleware.IdTrackerMiddleware',
    ....
    ....
    ]
````
- Add the logger settings in settings.py as below,

```python
import sys

LOGGING = {
    'version': 1,
    'disable_existing_loggers': True,
    'formatters': {
        'json': {'()': 'twsaas_common.tw_logging.log_formatter.JSONFormatter'},
        'audit_json': {'()': 'twsaas_common.tw_logging.log_formatter.AuditJSONFormatter'}
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'stream': sys.stdout,
            'formatter': 'json',
        },
        'audit_console': {
            'class': 'logging.StreamHandler',
            'stream': sys.stdout,
            'formatter': 'audit_json',
        }
    },
    'loggers': {
        '': {'handlers': ['console'], 'level': 'DEBUG', 'propagate': True},
        'django': {'handlers': ['console'], 'propagate': True, 'level': 'INFO'},
        'django.request': {'handlers': ['console'], 'propagate': False, 'level': 'INFO'},
        'audit': {'handlers': ['audit_console'], 'propagate': False, 'level': 'NOTSET'},
    },
}
```

- Now do the following to log any audit event. Please note that this audit logger should only be used for logging audit events. You would still need the tw_logging module for application logging purposes.

```python
from twsaas_common.tw_logging import audit as audit_logging

audit_logger = audit_logging.getAuditLog()

def ping(request):
    audit_logger.audit(
        "Audit Scan Started", resource="", resource_type="", action="Audit Scan Started", uri=request.path, method=request.method, status_code=""
    )
```
Example of audit log will be as below

```json
{"logType": "audit", "applicationName": "sample_rest_service", "tenantId": "dd62b2be-9f3b-4d11-ae78-9aebe069c704", "timestamp": "2019-09-11T10:00:50", "resource": "", "resourceType": null, "action": "Audit Scan Started", "uri": "/ping/", "method": "GET", "statusCode": null, "correlationId": "19b8efc0-0a76-476b-beb2-b511e94872a7", "sequenceId": "1", "description": "Audit Scan Started", "updatedFields": {}}
{"server_time": "13/Aug/2019 11:11:26", "status_code": 200, "log_level": "INFO", "time": "2019-08-13T11:11:26.492625", "message": "\"GET /ping/ HTTP/1.1\" 200 4"}
```

To get the `updated_fields` for audit log, you can use the following custom decorator, which will add the `updated_fields` 
in the self of that method. 

```python
from twsaas_common.tw_logging import audit as audit_logging
from twsaas_common.tw_logging.audit.utils import audit_updated_fields

audit_logger = audit_logging.getAuditLog()

@audit_updated_fields
def perform_create(self, serializer):
    super().perform_create(serializer)
    if getattr(self, "updated_fields", {}):
        audit_logger.audit(
            "created",
            resource=self.request.data.get("username"),
            resource_type=self.basename,
            uri=self.request.path,
            method=self.request.method,
            action="Created",
            updated_fields=getattr(self, "updated_fields", {}),
            status_code=None,
        )
        

```


## Sanitizing the Logs

Python has a rich and well designed Log System. `twsaas_common.tw_logging` uses it to implement several different features from adding context aware logs, to auditing the logs, and now even redacting sensitive information from the logs.

The redaction functionality utilizes the Log Filter capabilities of the Log System to assign a filter to the Log Handlers. This allows the redaction capability to be easily shared among all the various sources through simple configuration, or even to have different kinds of redaction based on the target log output handler.

All redacted data is replaced with the explicit term `REDACTED`. This is not a configurable option.

NOTE: The result of a redaction may leave some data contained within a string in an unusable form. For example, a string containing the JSON data `{ 'id': 53, 'email': 'no@body.net'}` will get over-redacted to `{ 'id': 53, 'email': REDACTED` by the default Email redaction. Regex-based redaction can only do so much in this respect. In general this isn't an issue as it's just log data contained within the log message. It's only an issue if one is trying to parse the log message data using another parser (e.g JSON) in order to extract something, e.g when trying to understand a recorded value within the log message.

### Configuration

Configuration is as simple as adding an appropriate `filters` section to the Log Configuration and telling any Log Handlers about the filter.

Each filter is given a name (f.e `sanitize`) that can then be used to reference it for application against loggers and handlers. It is highly recommended to only use a filter on the handlers.

The below is the simplest form of configuration and only activates the default capabilities for redaction:

```python
log_config = {
    'version': 1,
    'disable_existing_loggers': False,
    'filters': {
        'sanitize': {
            '()': 'twsaas_common.tw_logging.filter.LogSanitizer',
            'patterns': [],
        }
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'stream': sys.stdout,
            'filters': ['sanitize'],
        },
        'audit_console': {
            'class': 'logging.StreamHandler',
            'stream': sys.stderr,
            'filters': ['sanitize'],
        },
    },
    'loggers': {
        '': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': True,
        }
    },
}
```

### Default Redaction Capabilities

By default the functionality provided by `twsaas_common.tw_logging.filter.LogSanitizer` provides the following redaction capabilities:

Capability                     | description
-------------------------------|---------------------------------------------------------------------------
Basic SSWS Token Redaction     | Redacts the auth token used to talk with the Okta APIs (not the JWT Token)
Email Address Redaction (PII)  | Redacts most email addresses so as to hide personally identifiable info

NOTE: Email Address Redaction should cover the vast majority (99+%) of cases; however, identifying email addresses is a very hard task so it might not redact all forms.

### Custom Redactions

The `twsaas_common.tw_logging.filter.LogSanitizer` takes a `patterns` parameter for additional redactions. Each pattern in the list is a Python Regex.

If the Regex pattern includes a regex group (`My Name: (\w+)`) then only the group matched will be redacted.
If the Regex pattern does not include any regex groups (`My Name: \w+`) then the entire regex match will be redacted.

The following log config snippet shows the sanitizer configured with an additional customer filter:

```python
log_config = {
    ...
    'filters': {
        'sanitize': {
            '()': 'twsaas_common.tw_logging.filter.LogSanitizer',
            'patterns': [
                'Hello \w+',       # No regex group
                'Good-bye (\w+)',  # With a regex group
                '\s\w+\s',         # basically redact all words surronded by whitespace (not useful, just an example)
            ],
        }
    },
    ...
}
```

NOTE: Custom regex patterns will only be as good as the regex designer can make them.

NOTE: It is preferred to use regex groups in the regex to minimize what is redacted.

Some guidelines on Regex:

- When possible use `\w` instead of `[A-Za-z0-9]` as it will be more expansive for Unicode.
- Keep it simple; it's okay to overdact, but not okay to under-redact.
- Add some unit tests to your project to verify your custom regex is working as expected.

NOTE: The unit tests in `tests.tw_logger.test_filter` can be used as an example of how to test your regex.
