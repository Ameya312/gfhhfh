import json
import logging
from datetime import datetime

from twsaas_common.tw_logging.encoder import JsonEncoder


class JSONFormatter(logging.Formatter):
    def format(self, record):
        return json.dumps(self.json_record(record), cls=JsonEncoder)

    def json_record(self, record):
        record.asctime = self.formatTime(record, "%Y-%m-%dT%H:%M:%S")
        record.message = record.getMessage()
        record.log_level = record.levelname
        record_attrs = list(
            set(
                [
                    a
                    for a in dir(record)
                    if not a.startswith('__')
                    and a not in ["request", "getMessage", "args", "msg"]
                ]
            )
        )
        data = {attr_key: getattr(record, attr_key, '') for attr_key in record_attrs}
        if "time" not in data:
            data["time"] = datetime.utcnow()
        if record.exc_info:
            data["exc_info"] = self.formatException(record.exc_info)
        return data


class AuditJSONFormatter(JSONFormatter):
    def format(self, record):
        data = super().json_record(record)
        return json.dumps(
            {
                "logType": "audit",
                "applicationName": data.get("service_name"),
                "tenantId": data.get("tenant_id"),
                "user": data.get("user"),
                "timestamp": data.get("asctime"),
                "resource": data.get("resource"),
                "resourceType": data.get("resource_type"),
                "action": data.get("action"),
                "uri": data.get("uri"),
                "method": data.get("method"),
                "statusCode": data.get("status_code"),
                "correlationId": data.get("client_correlation_id"),
                "sequenceId": data.get("sequence"),
                "description": data.get("message"),
                "updatedFields": data.get("updated_fields", {}),
            },
            cls=JsonEncoder,
        )
