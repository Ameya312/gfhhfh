import decimal
import json
from datetime import date, datetime
from uuid import UUID


class JsonEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return float(o)
        elif isinstance(o, datetime) or isinstance(o, date):
            return o.isoformat()
        elif isinstance(o, UUID):
            return str(o)
        return super(JsonEncoder, self).default(o)
