import logging
import re


class LogSanitizer(logging.Filter):
    STANDARD_PATTERNS = [
        # Okta Bearer Token
        r'^.*?Authorization: SSWS (\w*).*?$',
        # Email Address Redaction
        # This isn't about validating email addresss here; but
        # about finding things that look like and email address
        # and redacting them
        r'(\S+@\S+\.\S+)',
    ]
    REDACTION_STATEMENT = 'REDACTED'

    def __init__(self, patterns, name=''):

        super(LogSanitizer, self).__init__(name)
        if patterns:
            patterns.extend(self.STANDARD_PATTERNS)
        else:
            patterns = self.STANDARD_PATTERNS
        self._regex = [re.compile(p) for p in patterns]

    def filter(self, record):
        """
        Log Record Filtering Interface

        Apply all the configured RegEx patterns against the log record
        """
        # Mutate the LogRecord so that the args no longer exist and the
        # msg is the final form of the message. This should make it easier
        # to apply the redaction
        formatted_message = record.getMessage()
        record.msg = formatted_message
        record.args = None

        # filter the data so it gets redacted
        for r in self._regex:
            # the regex will likely only match one item at a time even
            # if it's possible the pattern may match multiple times on
            # a line with different values matching. Therefore loop over
            # it until there are no more matches to be redacted
            for matches in r.finditer(record.msg):
                if matches.groups():
                    # Regex included a group entry to minimize the redaction
                    for mg in matches.groups():
                        record.msg = record.msg.replace(mg, self.REDACTION_STATEMENT)
                else:
                    # Regex did not include any group entry, just a pattern so replace the
                    # entire pattern, provided as `group(0)`.
                    record.msg = record.msg.replace(
                        matches.group(0), self.REDACTION_STATEMENT
                    )

        # Allow the record to continue to be processed and ultimately logged
        # there were no matches left to redact
        return True
