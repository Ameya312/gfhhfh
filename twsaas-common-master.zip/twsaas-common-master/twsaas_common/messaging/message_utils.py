import base64
import json
import zlib

import boto3  # type: ignore


def decompress_msg(msg):
    if not msg:
        return msg
    try:
        decompressed = zlib.decompress(base64.b64decode(msg))
    except Exception:
        return None
    else:
        try:
            # We don't want to return bytes if this was encoded utf-8
            return decompressed.decode('utf-8')
        except AttributeError:
            return decompressed


def compress_msg(msg):
    return base64.b64encode(zlib.compress(msg.encode('utf-8'))).decode('utf-8')


def get_s3_message(bucket, key):
    s3 = boto3.resource('s3')
    obj = s3.Object(bucket, key)
    message_body = obj.get()['Body'].read().decode('utf-8')
    if not message_body.startswith('{'):
        decompressed = decompress_msg(message_body)
        if decompressed:
            message_body = decompressed
    return json.loads(message_body)
