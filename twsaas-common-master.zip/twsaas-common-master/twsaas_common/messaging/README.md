# SNSMessagePublisher

A class for publishing messages via AWS SNS.

The SNSMessagePublisher standardizes how Tripwire publishes messages
using AWS SNS. Features include handling large messages which exceed
the maximum allowable SNS message size, uniform logging making it
possible to correlate the services involved in a particular opertation
and standardized JSON messaging structure simplifying subscribing to
SQS queues to SNS topics.

#### Example Use

This example creates the CustomerMessagePublisher subclass for
publishing Customer oriented messages.

```python
from twsaas_common.messaging.message_publisher import SNSMessagePublisher
from django.conf import settings

class CustomerMessagePublisher(SNSMessagePublisher):
    def __init__(self):
        super().__init__('customer-manager', uuid.uuid4(), settings.AWS_REGION)
        self.customer_topic_arn = settings.CUSTOMER_SNS_TOPIC_ARN

    def customer_created(
        self, request_id: uuid, customer_name: str, tenant_id: uuid, groups: List
    ) -> None:
        message = {
            'tenant_id': tenant_id,
            'customer_name': customer_name,
            'group_names': groups,
        }
        self.publish(
            message, self.customer_topic_arn, SUBJECT_CUSTOMER_CREATED, request_id
        )

    def customer_updated(
        self, request_id: uuid, customer_name: str, tenant_id: uuid, groups: List
    ) -> None:
        message = {
            'tenant_id': tenant_id,
            'customer_name': customer_name,
            'group_names': groups,
        }
        self.publish(
            message, self.customer_topic_arn, SUBJECT_CUSTOMER_UPDATED, request_id
        )
```

Here the the CustomerMessagePublisher is used in the Django Rest
Framework serializer for Customer objects, the publish method called
when new customers are created.

```python
import uuid

from django.db import transaction
from rest_framework import serializers

from .customer_message_publisher import CustomerMessagePublisher
from .models import Customer

publisher = CustomerMessagePublisher()
MSE_GROUP_NAME = 'managed-service-engineers'
groups = [MSE_GROUP_NAME]

class CustomerSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Customer
        fields = ('url', 'name', 'partner', 'tenant_id')

    def create(self, validated_data):
        with transaction.atomic():
            instance = super().create(validated_data)
            name = instance.name
            tenant_id = instance.tenant_id
            request_id = uuid.uuid4()
            publisher.customer_created(request_id, name, tenant_id, groups)
            return instance
```

# MessageConsumer

A class that can be inherited from for easily creating a new daemon that periodically
polls for new messages on a particular queue and reacts to those messages in some way.

#### Example Use

The following is an example django management command that utilizes MessageConsumer.

The message consumer can be started with `python manage.py my_command`

```python
import logging
import signal

from django.conf import settings
from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils.translation import ugettext as _

from scan_manager.rest_api.models import (
    Event,
)
from scan_manager.risk_assessment.models import ScannerInstance, VNEInstance
from scan_manager.shared_message_consumer import MessageConsumer
from scan_manager.util import (
    Logger,
)

LOG = logging.getLogger(__name__)


class ScanOrchestratorMessageConsumer(MessageConsumer):
    duplicate_auth_keys = _('Duplicate Auth Keys')
    duplicate_auth_keys_detail = _('Duplicate Auth Keys: {}')

    def process_message(self, body, message):
        if (
            body['TopicArn'] == settings.SCAN_ORCHESTRATOR_SNS_TOPIC_ARN
            and body['Subject']
            == Event.EVENT_SCAN_ORCHESTRATOR_ASSIGNED_VNE
        ):
            self.vne_assigned_to_scanner_instance(message)
            return True
        return False

    def vne_assigned_to_scanner_instance(self, message):
        # {
        #     'pk': '<scanner instance uuid>',
        #     'instance_id': 'vne instance_id',
        #     'local_ip_address': 'vne local ip address',
        #     'public_ip_address': 'vne public ip address',
        #     'auth_key': 'dp auth key',
        # }
        scanner_instance = self.get_obj_from_message(ScannerInstance, message, class_object_uuid='pk')
        if not scanner_instance:
            return
        LOG.debug(
            'vne_assigned_to_scanner_instance message',
            uuid=scanner_instance.pk,
            message=message,
        )
        vne_instance, created = VNEInstance.objects.get_or_create(instance_id=message['instance_id'], defaults={
            'local_ip_address': message['local_ip_address'],
            'public_ip_address': message['public_ip_address'],
        })
        vne_instance.local_ip_address = message['local_ip_address']
        vne_instance.public_ip_address = message['public_ip_address']
        vne_instance.save()
        scanner_instance.assigned_vne_instance = vne_instance
        scanner_instance.vne_auth_key = message['auth_key']
        scanner_instance.vne_last_update_seconds = -1
        scanner_instance.save()


class Command(BaseCommand):
    help = 'Consume scan orchestrator messages.'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.consumer = ScanOrchestratorMessageConsumer(
            incoming_queue_name=settings.INCOMING_SCAN_ORCHESTRATOR_QUEUE_NAME,
            error_subject='scan_orchestrator_message_consumer',
            log=LOG,
        )

    def _signal(self, signum, frame):
        self.consumer.time_to_die = True

    def handle(self, *args, **options):
        LOG.info('Scan Orchestrator message consumer is starting')

        signal.signal(signal.SIGTERM, self._signal)

        self.consumer.sqs_queue_loop()

        LOG.info('Scan Orchestrator message consumer stopping')

```
