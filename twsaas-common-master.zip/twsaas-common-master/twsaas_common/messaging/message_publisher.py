import json
from typing import Any, Dict, Mapping, Optional, Union
from uuid import UUID

import boto3  # type: ignore

from twsaas_common import tw_logging as logging

from ..exceptions import MessageTooLargeException
from .message_utils import compress_msg

DEFAULT_MAX_COMPRESSION_SIZE = 200000  # bytes

LOG = logging.getLogger(__name__)


class SNSMessagePublisher:
    """An AWS SNS message publishing class

    The SNSMessagePublisher standardizes how Tripwire publishes
    messages using AWS SNS. Features include handling large messages
    which exceed the maximum allowable SNS message size, uniform
    logging making it possible to correlate the services involved in a
    particular operation and standardized JSON messaging structure
    simplifying subscribing to SQS queues to SNS topics.

    Methods:
       publish: Publishes JSON messages to an AWS SNS topic.

    """

    def __init__(
        self,
        *args,
        aws_region='us-west-2',
        max_message_size=DEFAULT_MAX_COMPRESSION_SIZE,
        **kwargs,
    ):
        """
        The constructor for SNSMessagePublisher.

        Parameters:
            aws_region: The AWS Region name, defaults to us-west-2
            max_message_size: The maximum SNS message size in bytes, defaults to 200000 bytes

        """
        self.sns = boto3.client('sns', region_name=aws_region)
        self.max_message_size = max_message_size
        if 'service_name' in kwargs or 'service_id' in kwargs:
            LOG.info("Deprecated arguments service_name, service_id ignored")

    def publish(
        self,
        topic_arn: str,
        subject: str,
        message: Mapping[str, Any],
        request_id: Optional[UUID] = None,
    ) -> str:
        """Publish a JSON message to the SNS topic identified by the ARN.

        Parameters:
           topic_arn: the SNS topic on which to publish
           subject: The subject of the message.  This allows filtering when subscribing SQS queues to SNS topics. see: https://docs.aws.amazon.com/sns/latest/api/API_Publish.html
           message: a dict which will be serialized to JSON
           request_id: A uuid identifier established when the origin of the message is an HTTP request e.g. GraphQL mutation or REST Post. This allows for tracking user requests converted to messages through the system using logging.

        Raises:
           MessageTooLargeException: When the compressed message is larger than the maximum allowed SNS message size.
           botocore.exceptions.ClientError: When message handling fails

        Returns:
           The sns.publish response containing the unique message identifier see: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sns.html#SNS.Client.publish
        """
        message_to_send = self._base_message(message, request_id)
        LOG.info(
            "Sending message", extra={'request_id': request_id, 'subject': subject}
        )

        if self._requires_compression(message_to_send):
            # JSON serialized message to big to send, compress it
            LOG.info(
                "Large message size",
                extra={
                    'request_id': request_id,
                    'message_length': len(message_to_send),
                },
            )

            message_to_send = compress_msg(message_to_send)
            LOG.info(
                "Compressed message size",
                extra={
                    'request_id': request_id,
                    'message_length': len(message_to_send),
                },
            )

            if self._requires_s3_bucket(message_to_send):
                # TODO use https://github.scm.tripwire.com/tw-devops/vulnerability-scanner-service/blob/master/vulnerability_scanner_service/vulnerability_scanner_service.py#L494 as a template for sending really large messages
                # More importantliy this class needs to build s3 messages the message_consumer can consume
                raise MessageTooLargeException(
                    f"Really large message size, too large to send via SNS. request Id {request_id}, message length {len(message_to_send)}"
                )

        LOG.debug(
            "Message Payload",
            extra={'request_id': request_id, 'message_payload': message_to_send},
        )

        # Including message type for condional filtering when creating
        # subscriptions e.g. in Terraform
        message_attributes = {
            'MessageType': {'DataType': 'String', 'StringValue': subject}
        }
        response = self.sns.publish(
            TopicArn=topic_arn,
            Subject=subject,
            Message=message_to_send,
            MessageAttributes=message_attributes,
        )
        LOG.info(
            "Sent message",
            extra={'request_id': request_id, 'subject': subject, 'response': response},
        )

        return response

    def _requires_compression(self, message: str) -> bool:
        return len(message) > self.max_message_size

    def _requires_s3_bucket(self, message: str) -> bool:
        return len(message) > self.max_message_size

    def _base_message(
        self, message: Mapping[str, Any], request_id: Optional[UUID]
    ) -> str:
        base_message: Dict[str, Union[Mapping[str, Any], UUID]] = {**message}
        if request_id:
            base_message['request_id'] = request_id
        return json.dumps(base_message, default=str)
