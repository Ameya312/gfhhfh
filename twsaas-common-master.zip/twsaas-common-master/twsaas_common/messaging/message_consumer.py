import json
import traceback

import boto3
from django import db
from django.conf import settings
from django.db import transaction
from django.utils.translation import ugettext as _

from twsaas_common import tw_logging as logging

from .message_utils import decompress_msg, get_s3_message

LOG = logging.getLogger(__name__)


class SQSMocker(object):
    def __init__(self):
        self.sqs_queues = {}
        self.sns_topics = {}
        # https://github.com/spulec/moto/issues/1926
        boto3.setup_default_session()
        sqs_client = boto3.client('sqs')
        self.sqs_client = sqs_client
        sns_client = boto3.client('sns')
        self.sns_client = sns_client
        sns_resource = boto3.resource('sns', region_name=settings.AWS_REGION)
        self.sns_resource = sns_resource

    def get_override_settings(self):
        """
        Returns Django Settings overrides to be used in the override_settings decorator.
        """
        ret = {}
        for queue_name, topics in self.sqs_queues.items():
            ret[queue_name] = queue_name
            for topic_name, topic_arn in topics.items():
                ret[topic_name] = topic_arn
        return ret

    def create_mock_queue(self, queue_name, topic_names, queue_attributes=None):
        """
        Supply a queue_name and all topic_names subscribed to that queue to be mocked
        out.
        """
        if not queue_attributes:
            queue_attributes = {}

        self.sqs_client.create_queue(QueueName=queue_name, Attributes=queue_attributes)
        sqs_queue_url = self.sqs_client.get_queue_url(QueueName=queue_name)['QueueUrl']
        sqs_queue_attrs = self.sqs_client.get_queue_attributes(
            QueueUrl=sqs_queue_url, AttributeNames=['All']
        )['Attributes']
        sqs_queue_arn = sqs_queue_attrs['QueueArn']
        self.sqs_queues[queue_name] = {}

        for topic_name in topic_names:
            topic = self.sns_resource.create_topic(Name=topic_name)
            topic_arn = topic.arn
            self.sns_topics[topic_name] = topic
            self.sns_client.subscribe(
                TopicArn=topic_arn, Protocol='sqs', Endpoint=sqs_queue_arn
            )
            self.sqs_queues[queue_name][topic_name] = topic_arn


class MessageConsumer(object):
    json_decode_error = _('json decode error')
    json_decode_error_details = _('Decoding json \'{}\' for message \'{}\' failed')
    malformed_message = _('Message received is malformed')
    malformed_message_detail = _('The recieved message {} is malformed')
    unknown_message = _('Unknown message')
    unknown_message_details = _('Unknown message: {}')
    unknown_uuid_message = _('Unknown UUID')
    unknown_uuid_message_detail = _('UUID {} is unknown')

    def __init__(
        self, incoming_queue_name, error_subject, log=LOG, num_messages_per_read=10
    ):
        self.time_to_die = False
        self.sns = boto3.client('sns', region_name=settings.AWS_REGION)
        sqs = boto3.resource('sqs', region_name=settings.AWS_REGION)
        self.incoming_queue_name = incoming_queue_name
        self.error_subject = error_subject
        self.log = log
        self.num_messages_per_read = num_messages_per_read
        self.incoming_queue = sqs.get_queue_by_name(QueueName=incoming_queue_name)
        self.errored_messages = []

    def process_message(self, body, message):
        """
        Override this to perform some action based on a message pulled from a queue.
        """
        raise NotImplementedError('must implement')

    def process_messages(self):
        processed_id = 0
        processed = []
        messages = self.incoming_queue.receive_messages(
            MaxNumberOfMessages=self.num_messages_per_read
        )
        for mess in messages:
            if mess.message_id in self.errored_messages:
                continue
            try:
                with transaction.atomic():
                    self._process_message(mess)
            except (db.DatabaseError, db.utils.InterfaceError):
                self.log.exception('closing db connection')
                db.connection.close()
                # Don't record this message as processed
                continue
            except Exception:
                self.error_occured(
                    _('Exception processing message'), traceback.format_exc()
                )
                # We will no longer process this message
                self.errored_messages.append(mess.message_id)
                # Don't record this message as processed, we need to fix the issue and redeploy
                # to process the message successfully.
                continue

            processed.append(
                {'ReceiptHandle': mess.receipt_handle, 'Id': str(processed_id)}
            )
            processed_id += 1

        self._handle_processed_messages(processed)

    def _process_message(self, mess):
        try:
            body = json.loads(mess.body)
            if 'Message' not in body:
                subject = self.malformed_message
                detail = self.malformed_message_detail.format(body)
                self.error_occured(subject, detail)
                return

            message_body = body['Message']
            if not isinstance(message_body, str):
                subject = self.malformed_message
                detail = self.malformed_message_detail.format(body)
                self.error_occured(subject, detail)
                return

            if not message_body.startswith('{'):
                decompressed = decompress_msg(message_body)
                if decompressed:
                    message_body = decompressed
            message = json.loads(message_body)
        except json.JSONDecodeError as json_error:
            self.error_occured(
                self.json_decode_error,
                self.json_decode_error_details.format(json_error.doc, mess.body),
                extra={'json': json_error.doc, 'sqs_message': mess.body},
            )
            return

        self.log.debug(
            'process message', extra={'uuid': None, 'sqs_message_data': message}
        )
        if 'bucket' in message:
            message = get_s3_message(message['bucket'], message['key'])
            self.log.debug(
                'process message', extra={'uuid': None, 'sqs_message_data': message}
            )
        success = self.process_message(body, message)
        if not success:
            self.error_occured(
                self.unknown_message, self.unknown_message_details.format(body)
            )

    def _handle_processed_messages(self, processed):
        """
        Bulk deletes messages even if there are individual errors (old
        status messages aren't valuable)
        :param processed: List of all the processed messages
        """
        if processed:
            rc = self.incoming_queue.delete_messages(Entries=processed)
            if rc['ResponseMetadata']['HTTPStatusCode'] != 200:
                subject = _('Error deleting queued message')
                detail = _(
                    'Error deleting messages from queue {}, response {}'.format(
                        self.incoming_queue_name, rc
                    )
                )
                self.error_occured(subject, detail)
            del processed[:]

    def process_messages_no_transaction(self):
        """
        It processes messages for the services which don't have a database.
        """
        processed_id = 0
        processed = []
        messages = self.incoming_queue.receive_messages(
            MaxNumberOfMessages=self.num_messages_per_read
        )
        for mess in messages:
            if mess.message_id in self.errored_messages:
                continue
            try:
                self._process_message(mess)
            except Exception:
                self.error_occured(
                    _('Exception processing message'), traceback.format_exc()
                )
                # We will no longer process this message
                self.errored_messages.append(mess.message_id)
                # Don't record this message as processed, we need to fix the issue and redeploy
                # to process the message successfully.
                continue

            processed.append(
                {'ReceiptHandle': mess.receipt_handle, 'Id': str(processed_id)}
            )
            processed_id += 1
        self._handle_processed_messages(processed)

    def sqs_queue_loop(self):
        while True:
            if self.time_to_die:
                return
            try:
                self.process_messages()
            except Exception:
                self.log.exception('Unhandled exception in process messages')

    def sqs_queue_loop_no_transaction(self):
        """
        Services without database should use this method to process messages
        """
        while True:
            if self.time_to_die:
                return
            try:
                self.process_messages_no_transaction()
            except Exception:
                self.log.exception('Unhandled exception in process messages')

    def get_obj_from_message(self, get_class, message, class_object_uuid='uuid'):
        if not any(message):
            subject = self.malformed_message
            detail = self.malformed_message_detail.format(message)
            self.error_occured(subject, detail)
            return None
        uuid = message.get(class_object_uuid)
        if not uuid:
            subject = self.unknown_uuid_message
            detail = self.unknown_message_details.format(uuid)
            self.error_occured(subject, detail)
            return None
        obj = get_class.objects.filter(**{class_object_uuid: uuid})
        if not obj.exists():
            self.log.debug('unknown {} {}'.format(class_object_uuid, uuid))
            return None
        obj = obj.select_for_update().get()
        return obj

    def error_occured(self, subject, detail, extra=None):
        self.log.error(detail, extra=extra)
        self.send_sns_error(subject, detail)

    def send_sns_error(self, subject, detail):
        message = {'detail': detail}
        self.sns.publish(
            TopicArn=settings.ERRORS_SNS_TOPIC_ARN,
            Subject=f'{self.error_subject}-' + subject,
            Message=json.dumps({'default': json.dumps(message)}),
            MessageStructure='json',
        )
