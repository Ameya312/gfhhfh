ARTIFACT_MD5_CHECKSUM=`md5sum dist/* | awk '{print $1}'`; \
ARTIFACT_SHA1_CHECKSUM=`shasum -a 1 dist/* | awk '{ print $1 }'`; \
curl -u ${ARTIFACTORY_USER}:${ARTIFACTORY_PASS} -X PUT "https://artifactory.scm.tripwire.com/artifactory/${ARTIFACTORY_PATH}" \
-T dist/* \
--header "X-Checksum-MD5:${ARTIFACT_MD5_CHECKSUM}" \
--header "X-Checksum-Sha1:${ARTIFACT_SHA1_CHECKSUM}"
