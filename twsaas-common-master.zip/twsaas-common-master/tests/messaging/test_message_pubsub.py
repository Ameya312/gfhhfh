import json
import unittest
import uuid

import boto3
import botocore
import pytest
from django.conf import settings
from django.test import override_settings
from moto import mock_s3, mock_sns, mock_sqs

from twsaas_common import tw_logging as logging
from twsaas_common.exceptions import MessageTooLargeException
from twsaas_common.messaging.message_consumer import MessageConsumer, SQSMocker
from twsaas_common.messaging.message_publisher import SNSMessagePublisher

LOG = logging.getLogger(__name__)


class MessageConsumerExample(MessageConsumer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.took_action_on_message = None

    def process_message(self, body, message):
        if (
            body['TopicArn'] == settings.TEST_TOPIC_ARN
            and body['Subject'] == 'TEST_SUBJECT'
        ):
            self.test_action(message)
            return True
        return False

    def test_action(self, message):
        self.took_action_on_message = message


class TestProcessingMessageConsumer(MessageConsumer):
    def __init__(self, topic_arn, subject, *args, **kwargs):
        self.took_action_on_message = None
        self.topic_arn = topic_arn
        self.subject = subject
        super().__init__(*args, **kwargs)

    def process_message(self, body, message):
        if body['TopicArn'] == self.topic_arn and body['Subject'] == self.subject:
            self.took_action_on_message = message
            return True
        return False


class AlwaysCompressingMessagePublisher(SNSMessagePublisher):
    def _requires_compression(self, message: str) -> bool:
        return True

    def _requires_s3_bucket(self, message: str) -> bool:
        return False


class AlwaysS3MessagePublisher(SNSMessagePublisher):
    def _requires_compression(self, message: str) -> bool:
        return True

    def _requires_s3_bucket(self, message: str) -> bool:
        return True


ERROR_QUEUE_NAME = 'ERROR_QUEUE_NAME'


class TestMessagePubSub(unittest.TestCase):
    def do_test_good_message(self, compressed=False, s3_msg=False):
        sqs_mocker = SQSMocker()
        sqs_mocker.create_mock_queue(
            queue_name='INCOMING_QUEUE_NAME',
            topic_names=['TEST_TOPIC_ARN', 'ERRORS_SNS_TOPIC_ARN'],
        )
        topic = sqs_mocker.sns_topics['TEST_TOPIC_ARN']
        with override_settings(**sqs_mocker.get_override_settings()):
            orig_msg = {'uuid': '1234', 'test': 'thing'}
            service_id = uuid.uuid4()
            request_id = uuid.uuid4()

            publisher = SNSMessagePublisher(
                "test_service", **{"service_id": service_id}
            )
            if compressed:
                publisher = AlwaysCompressingMessagePublisher(
                    'compressing_message_test_service', **{"service_id": service_id}
                )
            if s3_msg:
                msg = json.dumps(orig_msg)
                s3 = boto3.resource('s3')
                obj = s3.Object('testbucket', 'message_key')
                obj.put(Body=msg)
                msg = json.dumps({'bucket': 'testbucket', 'key': 'message_key'})
                topic.publish(Message=msg, Subject='TEST_SUBJECT')
            else:
                topic_arn = sqs_mocker.sqs_queues['INCOMING_QUEUE_NAME'][
                    'TEST_TOPIC_ARN'
                ]
                publisher.publish(topic_arn, 'TEST_SUBJECT', orig_msg, request_id)

            consumer = MessageConsumerExample(
                incoming_queue_name='INCOMING_QUEUE_NAME',
                error_subject='ERROR_SUBJECT',
                log=LOG,
            )
            consumer.process_messages()

            if s3_msg:
                self.assertEqual(consumer.took_action_on_message, orig_msg)
            else:
                orig_msg['request_id'] = str(request_id)
                self.assertEqual(consumer.took_action_on_message, orig_msg)

    @pytest.mark.django_db
    @mock_sns
    @mock_sqs
    def test_message_success(self):
        self.do_test_good_message()

    @pytest.mark.django_db
    @mock_sns
    @mock_sqs
    def test_decompress_message(self):
        self.do_test_good_message(compressed=True)

    @pytest.mark.django_db
    @mock_sns
    @mock_sqs
    @mock_s3
    def test_s3_message(self):
        conn = boto3.resource('s3', region_name='us-east-2')
        conn.create_bucket(Bucket='testbucket')
        self.do_test_good_message(s3_msg=True)

    @pytest.mark.django_db
    @mock_sns
    @mock_sqs
    def test_unknown_message(self):
        sqs_mocker = SQSMocker()
        sqs_mocker.create_mock_queue(
            queue_name='INCOMING_QUEUE_NAME', topic_names=['TEST_TOPIC_ARN']
        )
        sqs_mocker.create_mock_queue(
            queue_name=ERROR_QUEUE_NAME, topic_names=['ERRORS_SNS_TOPIC_ARN']
        )
        topic = sqs_mocker.sns_topics['TEST_TOPIC_ARN']
        with override_settings(**sqs_mocker.get_override_settings()):
            msg = {'uuid': '1234', 'test': 'thing'}
            topic.publish(Message=json.dumps(msg), Subject='TEST_UNKNOWN_SUBJECT')
            consumer = MessageConsumerExample(
                incoming_queue_name='INCOMING_QUEUE_NAME',
                error_subject='ERROR_SUBJECT',
                log=LOG,
            )
            consumer.process_messages()
            self.assertFalse(consumer.took_action_on_message)

            # Make sure an error message was sent out
            sqs_resource = boto3.resource('sqs')
            error_q = sqs_resource.get_queue_by_name(QueueName=ERROR_QUEUE_NAME)
            messages = error_q.receive_messages(MaxNumberOfMessages=1)
            self.assertEqual(len(messages), 1)

    @pytest.mark.django_db
    @mock_sns
    @mock_sqs
    def test_consumer_post_publish(self):
        topic_name = 'CUSTOMER'
        subject = 'NewCustomer'
        msg = {
            'tenant_id': str(uuid.uuid4()),
            'groups': ['group1', 'group2'],
            'customer_name': 'Daddy Warbucks Inc',
        }

        sqs_mocker = SQSMocker()
        sqs_mocker.create_mock_queue(queue_name=topic_name, topic_names=[topic_name])
        topic = sqs_mocker.sns_topics[topic_name]
        sns_publisher = SNSMessagePublisher()
        request_id = uuid.uuid4()

        ret = sns_publisher.publish(topic.arn, subject, msg, request_id)
        self.assertTrue(ret)
        self.assertTrue(ret['MessageId'])

        with override_settings(**sqs_mocker.get_override_settings()):
            consumer = TestProcessingMessageConsumer(
                topic_arn=topic.arn,
                subject=subject,
                incoming_queue_name=topic_name,
                error_subject='ERROR_SUBJECT',
                log=LOG,
            )
            consumer.process_messages()
            msg['request_id'] = str(request_id)
            self.assertEqual(consumer.took_action_on_message, msg)

    @mock_sns
    @mock_sqs
    def test_producer_logging(self):
        topic_name = 'THINGY'
        subject = 'NewThing'
        msg = {'thing_id': str(uuid.uuid4()), 'thing_name': 'Doohicky'}

        sqs_mocker = SQSMocker()
        sqs_mocker.create_mock_queue(queue_name=topic_name, topic_names=[topic_name])
        topic = sqs_mocker.sns_topics[topic_name]
        sns_publisher = SNSMessagePublisher()
        request_id = uuid.uuid4()

        with self.assertLogs() as cm:
            sns_publisher.publish(topic.arn, subject, msg, request_id)
            for log_record in cm.records:
                self.assertEquals(log_record.request_id, request_id)
                if log_record.subject:
                    self.assertEquals(log_record.subject, subject)

    @pytest.mark.django_db
    @mock_sns
    @mock_sqs
    def test_no_request_id(self):
        topic_name = 'Muppet'
        subject = 'NewMuppet'
        msg = {'hecklers': ['Frank', 'Jerry'], 'muppet_name': 'Gonzo'}

        sqs_mocker = SQSMocker()
        sqs_mocker.create_mock_queue(queue_name=topic_name, topic_names=[topic_name])
        topic = sqs_mocker.sns_topics[topic_name]
        sns_publisher = SNSMessagePublisher()
        ret = sns_publisher.publish(topic.arn, subject, msg)
        self.assertTrue(ret)
        self.assertTrue(ret['MessageId'])

        with override_settings(**sqs_mocker.get_override_settings()):
            consumer = TestProcessingMessageConsumer(
                topic_arn=topic.arn,
                subject=subject,
                incoming_queue_name=topic_name,
                error_subject='ERROR_SUBJECT',
                log=LOG,
            )
            consumer.process_messages()
            self.assertEqual(consumer.took_action_on_message, msg)

    @pytest.mark.django_db
    @mock_sns
    @mock_sqs
    def test_empty_message(self):
        topic_name = 'Stuff'
        subject = 'NoStuff'
        msg = {}

        sqs_mocker = SQSMocker()
        sqs_mocker.create_mock_queue(queue_name=topic_name, topic_names=[topic_name])
        topic = sqs_mocker.sns_topics[topic_name]
        sns_publisher = SNSMessagePublisher()
        ret = sns_publisher.publish(topic.arn, subject, msg)
        self.assertTrue(ret)
        self.assertTrue(ret['MessageId'])

        with override_settings(**sqs_mocker.get_override_settings()):
            consumer = TestProcessingMessageConsumer(
                topic_arn=topic.arn,
                subject=subject,
                incoming_queue_name=topic_name,
                error_subject='ERROR_SUBJECT',
                log=LOG,
            )
            consumer.process_messages()
            self.assertEqual(consumer.took_action_on_message, msg)

    @mock_sns
    @mock_sqs
    def test_s3_worthy_message_throws(self):
        topic_name = 'Matrix'
        subject = 'NewMatrix'
        msg = {
            'maxtrix': [[x, y] for y in range(10) for x in range(10)],
            'matrix_id': str(uuid.uuid4()),
        }

        sqs_mocker = SQSMocker()
        sqs_mocker.create_mock_queue(queue_name=topic_name, topic_names=[topic_name])
        topic = sqs_mocker.sns_topics[topic_name]
        sns_publisher = AlwaysS3MessagePublisher()
        with self.assertRaises(MessageTooLargeException):
            sns_publisher.publish(topic.arn, subject, msg)

    @mock_sns
    @mock_sqs
    def test_topic_uninitialized(self):
        topic_name = 'Vegetables'
        subject = 'FreshVegetable'
        msg = {
            'veggy_id': str(uuid.uuid4()),
            'veggy': 'mache',
            'nicknames': ['lambs-tongue', 'corn salad', 'lambs-lettuce'],
        }
        uninitialized_topic_arn = f'arn:aws:sns:us-west-2:123456789012:{topic_name}'

        sns_publisher = SNSMessagePublisher()
        with self.assertRaises(botocore.exceptions.ClientError):
            sns_publisher.publish(uninitialized_topic_arn, subject, msg)

    def do_test_good_message_no_db(self, compressed=False, s3_msg=False):
        sqs_mocker = SQSMocker()
        sqs_mocker.create_mock_queue(
            queue_name='INCOMING_QUEUE_NAME',
            topic_names=['TEST_TOPIC_ARN', 'ERRORS_SNS_TOPIC_ARN'],
        )
        topic = sqs_mocker.sns_topics['TEST_TOPIC_ARN']
        with override_settings(**sqs_mocker.get_override_settings()):
            orig_msg = {'uuid': '1234', 'test': 'thing'}
            request_id = uuid.uuid4()

            publisher = SNSMessagePublisher()
            if compressed:
                publisher = AlwaysCompressingMessagePublisher()
            if s3_msg:
                msg = json.dumps(orig_msg)
                s3 = boto3.resource('s3')
                obj = s3.Object('testbucket', 'message_key')
                obj.put(Body=msg)
                msg = json.dumps({'bucket': 'testbucket', 'key': 'message_key'})
                topic.publish(Message=msg, Subject='TEST_SUBJECT')
            else:
                topic_arn = sqs_mocker.sqs_queues['INCOMING_QUEUE_NAME'][
                    'TEST_TOPIC_ARN'
                ]
                publisher.publish(topic_arn, 'TEST_SUBJECT', orig_msg, request_id)

            consumer = MessageConsumerExample(
                incoming_queue_name='INCOMING_QUEUE_NAME',
                error_subject='ERROR_SUBJECT',
                log=LOG,
            )
            consumer.process_messages_no_transaction()

            if s3_msg:
                self.assertEqual(consumer.took_action_on_message, orig_msg)
            else:
                orig_msg['request_id'] = str(request_id)
                self.assertEqual(consumer.took_action_on_message, orig_msg)

    @mock_sns
    @mock_sqs
    def test_message_success_no_db(self):
        self.do_test_good_message_no_db()

    @mock_sns
    @mock_sqs
    def test_decompress_message_no_db(self):
        self.do_test_good_message_no_db(compressed=True)

    @mock_sns
    @mock_sqs
    @mock_s3
    def test_s3_message_no_db(self):
        conn = boto3.resource('s3', region_name='us-east-2')
        conn.create_bucket(Bucket='testbucket')
        self.do_test_good_message_no_db(s3_msg=True)

    @mock_sns
    @mock_sqs
    def test_unknown_message_no_db(self):
        sqs_mocker = SQSMocker()
        sqs_mocker.create_mock_queue(
            queue_name='INCOMING_QUEUE_NAME', topic_names=['TEST_TOPIC_ARN']
        )
        sqs_mocker.create_mock_queue(
            queue_name=ERROR_QUEUE_NAME, topic_names=['ERRORS_SNS_TOPIC_ARN']
        )
        topic = sqs_mocker.sns_topics['TEST_TOPIC_ARN']
        with override_settings(**sqs_mocker.get_override_settings()):
            msg = {'uuid': '1234', 'test': 'thing'}
            topic.publish(Message=json.dumps(msg), Subject='TEST_UNKNOWN_SUBJECT')
            consumer = MessageConsumerExample(
                incoming_queue_name='INCOMING_QUEUE_NAME',
                error_subject='ERROR_SUBJECT',
                log=LOG,
            )
            consumer.process_messages_no_transaction()
            self.assertFalse(consumer.took_action_on_message)

            # Make sure an error message was sent out
            sqs_resource = boto3.resource('sqs')
            error_q = sqs_resource.get_queue_by_name(QueueName=ERROR_QUEUE_NAME)
            messages = error_q.receive_messages(MaxNumberOfMessages=1)
            self.assertEqual(len(messages), 1)

    @mock_sns
    @mock_sqs
    def test_consumer_post_publish_no_db(self):
        topic_name = 'CUSTOMER'
        subject = 'NewCustomer'
        msg = {
            'tenant_id': str(uuid.uuid4()),
            'groups': ['group1', 'group2'],
            'customer_name': 'Daddy Warbucks Inc',
        }

        sqs_mocker = SQSMocker()
        sqs_mocker.create_mock_queue(queue_name=topic_name, topic_names=[topic_name])
        topic = sqs_mocker.sns_topics[topic_name]
        sns_publisher = SNSMessagePublisher()
        request_id = uuid.uuid4()

        ret = sns_publisher.publish(topic.arn, subject, msg, request_id)
        self.assertTrue(ret)
        self.assertTrue(ret['MessageId'])

        with override_settings(**sqs_mocker.get_override_settings()):
            consumer = TestProcessingMessageConsumer(
                topic_arn=topic.arn,
                subject=subject,
                incoming_queue_name=topic_name,
                error_subject='ERROR_SUBJECT',
                log=LOG,
            )
            consumer.process_messages_no_transaction()
            msg['request_id'] = str(request_id)
            self.assertEqual(consumer.took_action_on_message, msg)

    @mock_sns
    @mock_sqs
    def test_no_request_id_no_db(self):
        topic_name = 'Muppet'
        subject = 'NewMuppet'
        msg = {'hecklers': ['Frank', 'Jerry'], 'muppet_name': 'Gonzo'}

        sqs_mocker = SQSMocker()
        sqs_mocker.create_mock_queue(queue_name=topic_name, topic_names=[topic_name])
        topic = sqs_mocker.sns_topics[topic_name]
        sns_publisher = SNSMessagePublisher()
        ret = sns_publisher.publish(topic.arn, subject, msg)
        self.assertTrue(ret)
        self.assertTrue(ret['MessageId'])

        with override_settings(**sqs_mocker.get_override_settings()):
            consumer = TestProcessingMessageConsumer(
                topic_arn=topic.arn,
                subject=subject,
                incoming_queue_name=topic_name,
                error_subject='ERROR_SUBJECT',
                log=LOG,
            )
            consumer.process_messages_no_transaction()
            self.assertEqual(consumer.took_action_on_message, msg)

    @mock_sns
    @mock_sqs
    def test_empty_message_no_db(self):
        topic_name = 'Stuff'
        subject = 'NoStuff'
        msg = {}

        sqs_mocker = SQSMocker()
        sqs_mocker.create_mock_queue(queue_name=topic_name, topic_names=[topic_name])
        topic = sqs_mocker.sns_topics[topic_name]
        sns_publisher = SNSMessagePublisher()
        ret = sns_publisher.publish(topic.arn, subject, msg)
        self.assertTrue(ret)
        self.assertTrue(ret['MessageId'])

        with override_settings(**sqs_mocker.get_override_settings()):
            consumer = TestProcessingMessageConsumer(
                topic_arn=topic.arn,
                subject=subject,
                incoming_queue_name=topic_name,
                error_subject='ERROR_SUBJECT',
                log=LOG,
            )
            consumer.process_messages_no_transaction()
            self.assertEqual(consumer.took_action_on_message, msg)

    def do_test_bad_message_processing(self, message_text):
        sqs_mocker = SQSMocker()
        queue_name = 'bad_messages_queue'
        sqs_mocker.create_mock_queue(
            queue_name=queue_name, topic_names=['ERRORS_SNS_TOPIC_ARN']
        )
        with override_settings(**sqs_mocker.get_override_settings()):
            with self.assertLogs(level='ERROR') as cm:
                message_consumer = MessageConsumer(
                    incoming_queue_name=queue_name, error_subject='bad_message'
                )
                message_consumer._process_message(TestMessage(message_text))
                self.assertTrue(cm.output[0].startswith('ERROR'))

    @mock_sns
    @mock_sqs
    def test_bad_message_text(self):
        self.do_test_bad_message_processing("bad cheese")

    @mock_sns
    @mock_sqs
    def test_bad_no_message_json(self):
        message = json.dumps({'fuzzy': 'cheese'})
        self.do_test_bad_message_processing(message)

    @mock_sns
    @mock_sqs
    def test_bad_message_json(self):
        message = json.dumps({'Message': 'green cheese'})
        self.do_test_bad_message_processing(message)

    @mock_sns
    @mock_sqs
    def test_bad_message_empty_list(self):
        message = json.dumps({'Message': []})
        self.do_test_bad_message_processing(message)

    @mock_sns
    @mock_sqs
    def test_bad_message_none(self):
        message = json.dumps({'Message': None})
        self.do_test_bad_message_processing(message)


class TestMessage(object):
    def __init__(self, body_text):
        self.body = body_text
