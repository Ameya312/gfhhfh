import importlib
import unittest
import uuid

try:
    from django.test import override_settings

    enable_django_testing = True
except ImportError:
    enable_django_testing = False


class DjangoTestCase(unittest.TestCase):
    @staticmethod
    def make_user_id():
        return str(uuid.uuid4())

    @staticmethod
    def make_value():
        return str(uuid.uuid4()).replace('-', '')

    @classmethod
    def make_company(cls):
        return cls.make_value()

    @classmethod
    def make_email(cls, user=None, company=None):
        if user is None:
            user = cls.make_value()

        if company is None:
            company = cls.make_value()

        return f'{user}@{company}.testing'

    @classmethod
    def make_user_dict(
        cls, sub=None, email=None, company=None, given_name=None, family_name=None
    ):
        # NOTE: company, given_name, and family_name are only used for
        # building an email address if it was not provided. They are otherwise
        # ignored for this test utility object

        # company, given_name, and family_name are used to build the
        # email if not provided so must be generated in a re-usable context
        if company is None:
            company = cls.make_company()

        if given_name is None:
            given_name = cls.make_value()

        if family_name is None:
            family_name = cls.make_value()

        return {
            'userid': sub if sub is not None else cls.make_user_id(),
            'email': email
            if email is not None
            else cls.make_email(user=f'{given_name}.{family_name}', company=company),
        }

    @classmethod
    def make_jwt_payload(cls, user_dict):
        return {
            'sub': user_dict['userid'],
            'event_id': str(uuid.uuid4()),
            'token_use': 'access',
            'scope': '',
            'auth_time': 0,
            'iss': 'oidc.me',
            'exp': 2,
            'iat': 1,
            'jti': str(uuid.uuid4()),
            'client_id': str(uuid.uuid4()).replace('-', ''),
            'username': user_dict['userid'],
        }

    @classmethod
    def make_user_model_dict(cls, user_dict):
        return {'username': user_dict['userid']}

    def check_django_availability(self):
        if not enable_django_testing:
            self.skipTest('Django Settings Override Not Available')

        try:
            # imported just to check if it's available; so make flake8 ignore it
            from django.conf import settings  # noqa
        except ImportError:
            self.skipTest('Django Settings Not Available')


def auth_django_settings(module_to_reimport, django_settings_dict):
    """
    Decorator for the default Django Settings Required for
    the Authentication Unit Tests
    """

    def fn_decorator(fn):
        def wrapper(*args, **kwargs):
            # If Django is available then override the settings with the
            # default settings required for the Auth functionality
            if enable_django_testing:
                with override_settings(
                    **(django_settings_dict if django_settings_dict else {})
                ):
                    # Reimport the module to ensure the expected default
                    # settings are in place as the tests validate some
                    # of the default settings to ensure changes are
                    # happening as expected
                    if module_to_reimport:
                        importlib.reload(module_to_reimport)
                    return fn(*args, **kwargs)
            else:
                # If the decorator is attached to a class method
                # then call the class's `skipTest` method
                if args and isinstance(args[0], unittest.TestCase):
                    test_case = args[0]
                    return test_case.skipTest("Django not available")
                else:
                    # otherwise, just raise SkipTest directly
                    raise unittest.SkipTest("Django not available")

        return wrapper

    return fn_decorator
