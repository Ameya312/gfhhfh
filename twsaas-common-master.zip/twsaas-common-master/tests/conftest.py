from django.conf import settings


def pytest_configure():
    settings.configure(
        INSTALLED_APPS=[
            'django.contrib.auth',
            'django.contrib.contenttypes',
            'twsaas_common',
            'tests',
        ],
        DATABASES={
            'default': {'ENGINE': 'django.db.backends.sqlite3', 'NAME': ':memory:'}
        },
        LOGGING={
            'version': 1,
            'disable_existing_loggers': True,
            'handlers': {'null': {'class': 'logging.NullHandler'}},
        },
        AWS_REGION='us-west-2',
        ERRORS_SNS_TOPIC_ARN='error_topic',
        AUTH_USER_MODEL='tests.FlatStanleyUser',
        JWT_AUTH={'JWT_AUTH_HEADER_PREFIX': 'Bearer', 'JWT_PRIVATE_KEY': 'secret'},
    )
