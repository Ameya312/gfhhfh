import jwt
import pytest
from mock import Mock

import twsaas_common.tracker as tracker
from twsaas_common.tracker.id_tracker import generate_uuid
from twsaas_common.tracker.middleware import IdTrackerMiddleware
from twsaas_common.tracker.utils import set_request_data_to_storage


def test_init_middleware():
    id_middleware = IdTrackerMiddleware('response')
    assert tracker.context.start_time is None
    assert id_middleware.get_response == 'response'


def test_initialize_tracker():
    assert tracker.context.start_time is None
    tracker.initialize_tracker()
    assert tracker.context.start_time is not None
    tracker.reset_tracker()
    assert tracker.context.start_time is None


def test_client_correlation_id_from_header():
    request = Mock()
    uuid = generate_uuid()
    request.META = {"HTTP_X_CLIENT_CORRELATION_ID": uuid}
    tracker.initialize_tracker()
    set_request_data_to_storage(request)
    assert tracker.context.client_correlation_id == uuid
    tracker.reset_tracker()


def test_middleware_set_client_correlation_id_if_not_header():
    request = Mock()
    request.META = {}
    tracker.initialize_tracker()
    set_request_data_to_storage(request)
    assert tracker.context.client_correlation_id is not None
    tracker.reset_tracker()


def test_auto_set_service_transaction_id():
    request = Mock()
    request.META = {}
    tracker.initialize_tracker()
    set_request_data_to_storage(request)
    assert tracker.context.server_transaction_id is not None
    tracker.reset_tracker()


@pytest.mark.django_db
def test_middleware_clear_thread_local():
    request = Mock()
    request.META = {}
    assert tracker.context.start_time is None
    my_middleware = IdTrackerMiddleware(Mock())
    my_middleware(request)
    assert tracker.context.start_time is None


def test_clear_tracker_attributes():
    tracker.initialize_tracker()
    tracker.context.foo = 'bar'
    tracker.reset_tracker()
    assert not hasattr(tracker.context, 'foo')


@pytest.mark.parametrize('auth_key', ('Authorization', 'HTTP_AUTHORIZATION'))
def test_authentication_information_in_thread_local(auth_key):
    request = Mock()
    user_id = '409a3f99-49cd-4d30-a80f-032c98aae645'
    tenant_id = '31bc3a64-013e-4ed7-bf44-ab0df49adfa5'
    jwt_token = jwt.encode({'sub': user_id, 'tenant_id': tenant_id}, key='secret')
    request.META = {auth_key: "Bearer {0}".format(jwt_token.decode())}

    tracker.initialize_tracker()
    set_request_data_to_storage(request)

    assert tracker.context.tenant_id == tenant_id
    assert tracker.context.user == user_id
    tracker.reset_tracker()


@pytest.mark.parametrize('auth_key', ('Authorization', 'HTTP_AUTHORIZATION'))
def test_authentication_information_in_thread_local_non_jwt_auth(auth_key):
    request = Mock()
    jwt_token = 'non_jwt_bearer_token_in_headers'
    request.META = {auth_key: "Bearer {0}".format(jwt_token)}

    tracker.initialize_tracker()
    set_request_data_to_storage(request)

    assert tracker.context.tenant_id is None
    assert tracker.context.user is None
    tracker.reset_tracker()
