"""
Testing Objects
"""
from django.contrib.auth.models import AbstractBaseUser, UserManager
from django.db import models
from django.db.utils import IntegrityError


class FlatStanleyUser(AbstractBaseUser):
    """
    Standin user model for the tests
    """

    username = models.TextField(primary_key=True, editable=False, blank=False)
    email = models.EmailField(null=True)

    objects = UserManager()

    # This should match what is used in tests.django_base
    # NOTE: `username` is the default per AbstractBaseUser, just being explicit
    #   here for test purposes.
    USERNAME_FIELD = 'username'

    def __init__(self, *args, groups=None, active=False, **kwargs):
        super(FlatStanleyUser, self).__init__(*args, **kwargs)
        self.groups = kwargs['groups'] if 'groups' in kwargs else list()
        self.active = active
        self.save_called = False

    def save(self, *args, **kwargs):
        super(FlatStanleyUser, self).save(*args, **kwargs)
        self.save_called = True


class DummyUserManager(object):
    class DoesNotExist(Exception):
        pass

    # This should match what is used in tests.django_base
    USERNAME_FIELD = 'username'

    def __init__(self, user_to_return, user_exists=True, integrity_error=False):
        self.objects = self
        self.user_to_return = user_to_return
        self.create_args = None
        self.get_args = None
        self.get_by_natural_key_args = None
        self.user_exists = user_exists
        self.integrity_error = integrity_error

    def get(self, *args, **kwargs):
        self.get_args = (args, kwargs)
        if self.user_exists:
            return self.user_to_return
        else:
            raise self.DoesNotExist

    def get_by_natural_key(self, *args, **kwargs):
        self.get_by_natural_key_args = (args, kwargs)
        if self.user_exists:
            return self.user_to_return
        else:
            raise self.DoesNotExist

    def create(self, *args, **kwargs):
        self.create_args = (args, kwargs)
        if self.integrity_error:
            raise IntegrityError
        else:
            return self.user_to_return
