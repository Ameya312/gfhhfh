import json
import logging
import unittest
from datetime import datetime

from twsaas_common import tw_logging
from twsaas_common.tracker import initialize_tracker, reset_tracker
from twsaas_common.tracker.utils import init_tracker, set_request_data_to_storage
from twsaas_common.tw_logging.log_formatter import JSONFormatter

try:
    from cStringIO import StringIO
except ImportError:
    from io import StringIO

log_buffer = StringIO()
tw_handler = logging.StreamHandler(log_buffer)

logger = logging.getLogger('test')
logger.addHandler(tw_handler)
logger.setLevel(logging.DEBUG)
logger_adapter = tw_logging.TwLogAdapter(logger, extra={})

DATETIME = datetime(2015, 9, 1, 6, 9, 42, 797203)
DATETIME_ISO = u'2019-05-01T06:09:42.797203'


class TestCase(unittest.TestCase):
    def tearDown(self):
        log_buffer.seek(0)
        log_buffer.truncate()


class LoggerTest(TestCase):
    def setUp(self):
        tw_handler.setFormatter(JSONFormatter())

    def test_given_time_is_used_in_log_record(self):
        logger.info('Scan Started', extra={'time': DATETIME})
        expected_time = '"time": "2015-09-01T06:09:42.797203"'
        self.assertIn(expected_time, log_buffer.getvalue())

    def test_current_time_is_used_by_default_in_log_record(self):
        logger.info('Scan Started', extra={'fizz': 'bazz'})
        self.assertNotIn(DATETIME_ISO, log_buffer.getvalue())

    def test_logging_message_without_extra_data(self):
        logger.info('Scan Started')
        json_record = json.loads(log_buffer.getvalue())
        expected_fields = {'message', 'time', 'log_level'}
        self.assertTrue(expected_fields.issubset(set(json_record)))

    def test_logging_message_with_extra_data(self):
        logger.info('Scan Started', extra={'fizz': 'bazz'})
        json_record = json.loads(log_buffer.getvalue())
        expected_fields = {'message', 'time', 'fizz', 'log_level'}
        self.assertTrue(expected_fields.issubset(set(json_record)))

    def test_logging_message_default_using_adapter(self):
        initialize_tracker()
        set_request_data_to_storage()
        logger_adapter.info('Scan Started')
        json_record = json.loads(log_buffer.getvalue())
        expected_fields = {
            'server_transaction_id',
            'client_correlation_id',
            'message',
            'time',
            'log_level',
            'service_name',
            'container_id',
        }
        self.assertTrue(expected_fields.issubset(set(json_record)))
        reset_tracker()

    def test_logging_message_with_extra_data_using_adapter(self):
        initialize_tracker()
        set_request_data_to_storage()
        logger_adapter.info('Scan Started', extra={'fizz': 'bazz'})
        json_record = json.loads(log_buffer.getvalue())
        expected_fields = {
            'message',
            'time',
            'fizz',
            'log_level',
            'client_correlation_id',
            'server_transaction_id',
            'service_name',
            'container_id',
        }
        self.assertTrue(expected_fields.issubset(set(json_record)))
        reset_tracker()

    def test_logging_message_default_using_decorator(self):
        @init_tracker
        def test_decorator():
            logger_adapter.info('Scan Started')
            return json.loads(log_buffer.getvalue())

        expected_fields = {
            'server_transaction_id',
            'client_correlation_id',
            'message',
            'time',
            'log_level',
            'service_name',
            'container_id',
        }
        json_record = test_decorator()
        self.assertTrue(expected_fields.issubset(set(json_record)))

    def test_exc_info_is_logged(self):
        try:
            raise ValueError('something wrong')
        except ValueError:
            logger_adapter.error('Request failed', exc_info=True)
        json_record = json.loads(log_buffer.getvalue())
        self.assertIn('Traceback (most recent call last)', json_record['exc_info'])


if __name__ == '__main__':
    unittest.main()
