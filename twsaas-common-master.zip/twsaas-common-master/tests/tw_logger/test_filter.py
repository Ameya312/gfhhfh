import copy
import logging
import unittest
import uuid

import ddt

from twsaas_common.tw_logging.filter import LogSanitizer

try:
    from cStringIO import StringIO
except ImportError:
    from io import StringIO


TOKEN_REDACTION_DATA = [
    ("TheTokenGoesHere", "REDACTED"),
    ("TheTokenGoesHere TheTokenGoesHere", "REDACTED REDACTED"),
]

EMAIL_ADDRESS_REDACTION_DATA = [
    ('bar+foo@example.test', 'REDACTED'),
    ("o'snap@foo.bar", 'REDACTED'),
    ("example+!#$%&'*-/=?^_`{|}~@example.test", 'REDACTED'),
    (
        "Barfolomew@eagle5.spaceballs something LoneStar@eagle5.spaceballs else Vespa@druidia.spaceballs",
        "REDACTED something REDACTED else REDACTED",
    ),
]


class DummyRecord(object):
    """
    Simpler version of LogRecord that is easier to instantiate as
    it only has the the required pieces to make testing simpler
    """

    def __init__(self):
        self.msg = ''
        self.args = []

    def __eq__(self, other):
        return self.msg == other.msg and self.args == other.args

    def getMessage(self):
        msg = str(self.msg)
        if self.args:
            msg = msg % self.args
        return msg


@ddt.ddt
class LoggerTest(unittest.TestCase):
    def setUp(self):
        self.log_buffer = StringIO()

    def tearDown(self):
        self.log_buffer.seek(0)
        self.log_buffer.truncate()

    @ddt.data([], None, [r'(\s)'], [r'(.*)', r'(\s\s\s) (\s\d\s)'])
    def test_initialization(self, extra_patterns):
        expected_patterns = []
        if extra_patterns:
            expected_patterns.extend(extra_patterns)
        expected_patterns.extend(LogSanitizer.STANDARD_PATTERNS)

        name = 'boloney'
        instance = LogSanitizer(expected_patterns, name=name)
        self.assertEqual(instance.name, name)
        instance_patterns = [r.pattern for r in instance._regex]
        self.assertEqual(sorted(instance_patterns), sorted(expected_patterns))

    @ddt.data(*TOKEN_REDACTION_DATA)
    @ddt.unpack
    def test_filter_record(self, token_data, redaction_data):
        dummyRecord = DummyRecord()
        dummyRecord.msg = 'Authorization: SSWS %s %s %s'
        dummyRecord.args = tuple([token_data, 'v2', 'v3'])
        expectedRecord = DummyRecord()
        expectedRecord.msg = f'Authorization: SSWS {redaction_data} v2 v3'
        expectedRecord.args = None

        self.assertNotEqual(dummyRecord, expectedRecord)
        instance = LogSanitizer(None, name='foobar_test')
        try:
            result = instance.filter(dummyRecord)
        except (TypeError, ValueError) as ex:
            raise Exception(f'Error - {dummyRecord.msg} - {dummyRecord.args}') from ex
        self.assertTrue(result)
        self.assertEqual(dummyRecord.msg, expectedRecord.msg)
        self.assertEqual(dummyRecord.args, expectedRecord.args)
        self.assertEqual(dummyRecord, expectedRecord)

    def test_filter_record_ungrouped_regex(self):
        dummyRecord = DummyRecord()
        dummyRecord.msg = 'Peter Piper picked a peck of pickled peppers. How many peppers did Peter Piper pick?'
        dummyRecord.args = None
        expectedRecord = DummyRecord()
        expectedRecord.msg = (
            'REDACTEDed a peck of pickled peppers. How many peppers did REDACTED?'
        )
        expectedRecord.args = None

        self.assertNotEqual(dummyRecord, expectedRecord)
        instance = LogSanitizer([r'Peter \w+ pick'], name='foobar_test')
        try:
            result = instance.filter(dummyRecord)
        except (TypeError, ValueError) as ex:
            raise Exception(f'Error - {dummyRecord.msg} - {dummyRecord.args}') from ex
        self.assertTrue(result)
        self.assertEqual(dummyRecord.msg, expectedRecord.msg)
        self.assertEqual(dummyRecord.args, expectedRecord.args)
        self.assertEqual(dummyRecord, expectedRecord)

    @ddt.data(*TOKEN_REDACTION_DATA)
    @ddt.unpack
    def test_filter_log_record(self, token_data, redaction_data):
        original = {
            'name': 'a',
            'level': logging.DEBUG,
            'pathname': 'foo/bar',
            'lineno': 394,
            'msg': 'Authorization: SSWS %s %s %s',
            'args': tuple([token_data, 'v2', 'v3']),
            'exc_info': None,
            'func': 'bar',
            'sinfo': None,
        }
        updated = {}
        updated.update(original)
        updated['msg'] = f'Authorization: SSWS {redaction_data} v2 v3'
        updated['args'] = None

        dummyRecord = logging.LogRecord(**original)
        expectedRecord = logging.LogRecord(**updated)

        self.assertNotEqual(dummyRecord, expectedRecord)
        instance = LogSanitizer(None, name='foobar_test')
        result = instance.filter(dummyRecord)
        self.maxDiff = None
        self.assertTrue(result)
        self.assertEqual(dummyRecord.getMessage(), expectedRecord.msg)
        self.assertEqual(dummyRecord.args, expectedRecord.args)

    @ddt.data(*EMAIL_ADDRESS_REDACTION_DATA)
    @ddt.unpack
    def test_filter_email_log_record_via_args(self, email_address, redaction_data):
        original = {
            'name': 'a',
            'level': logging.DEBUG,
            'pathname': 'foo/bar',
            'lineno': 394,
            'msg': f"period %s",
            'args': {'key': 'foo', 'email': email_address, 'bot': 'f34r'},
            'exc_info': None,
            'func': 'bar',
            'sinfo': None,
        }
        updated = copy.deepcopy(original)
        updated[
            'msg'
        ] = f"period {{'key': 'foo', 'email': {redaction_data} 'bot': 'f34r'}}"
        updated['args'] = None

        dummyRecord = logging.LogRecord(**original)
        expectedRecord = logging.LogRecord(**updated)

        self.assertNotEqual(dummyRecord, expectedRecord)
        instance = LogSanitizer(None, name='foobar_test')
        result = instance.filter(dummyRecord)
        self.maxDiff = None
        self.assertTrue(result)
        self.assertEqual(dummyRecord.getMessage(), updated['msg'])
        self.assertEqual(dummyRecord.msg, expectedRecord.msg)
        self.assertEqual(dummyRecord.args, expectedRecord.args)

    @ddt.data(*EMAIL_ADDRESS_REDACTION_DATA)
    @ddt.unpack
    def test_filter_email_log_record_random_msg(self, email_address, redaction_data):
        original = {
            'name': 'a',
            'level': logging.DEBUG,
            'pathname': 'foo/bar',
            'lineno': 394,
            'msg': f"period %s",
            'args': f"The message was sent to {email_address}",
            'exc_info': None,
            'func': 'bar',
            'sinfo': None,
        }
        updated = copy.deepcopy(original)
        updated['msg'] = f"period The message was sent to {redaction_data}"
        updated['args'] = None

        dummyRecord = logging.LogRecord(**original)
        expectedRecord = logging.LogRecord(**updated)

        self.assertNotEqual(dummyRecord, expectedRecord)
        instance = LogSanitizer(None, name='foobar_test')
        result = instance.filter(dummyRecord)
        self.maxDiff = None
        self.assertTrue(result)
        self.assertEqual(dummyRecord.getMessage(), updated['msg'])
        self.assertEqual(dummyRecord.msg, expectedRecord.msg)
        self.assertEqual(dummyRecord.args, expectedRecord.args)

    @ddt.data(*EMAIL_ADDRESS_REDACTION_DATA)
    @ddt.unpack
    def test_filter_email_log_record_jwt(self, email_address, redaction_data):
        customer_id = str(uuid.uuid4())
        sub = str(uuid.uuid4())
        tenant_id = str(uuid.uuid4())
        original = {
            'name': 'a',
            'level': logging.DEBUG,
            'pathname': 'foo/bar',
            'lineno': 394,
            'msg': f"period {{'ver': 1, 'jti': 'foo', 'iss': 'https://example/oauth2/default', 'aud': 'bar', 'iat': 1570221077, 'exp': 1570221977, 'cid': 'entropy', 'uid': 'motion', 'scp': ['openid', 'email', 'profile'], 'tenant_id': '{tenant_id}', 'sub': '{sub}', 'roles': ['AssetUser', 'ConnectAdmin', 'ConnectUser', 'CustomerAdmin', 'DataAdapterAdmin', 'DevOpsUser', 'ExpertOpsAdmin', 'ExpertOpsBetaTester', 'ExpertOpsSCMUser', 'ExpertOpsUser', 'ExpertOpsVMUser', 'ISE-Test', 'ISETEST', 'PartnerAdmin', 'SuperAdmin', 'TagAdmin', 'TagUser', 'TripwireForDevOpsAdmin', 'TripwireSystemAdmin', 'AssetAdmin'], 'customer_id': '{customer_id}', 'email': '{email_address}'}}",
            'args': None,
            'exc_info': None,
            'func': 'bar',
            'sinfo': None,
        }
        updated = copy.deepcopy(original)
        updated[
            'msg'
        ] = f"period {{'ver': 1, 'jti': 'foo', 'iss': 'https://example/oauth2/default', 'aud': 'bar', 'iat': 1570221077, 'exp': 1570221977, 'cid': 'entropy', 'uid': 'motion', 'scp': ['openid', 'email', 'profile'], 'tenant_id': '{tenant_id}', 'sub': '{sub}', 'roles': ['AssetUser', 'ConnectAdmin', 'ConnectUser', 'CustomerAdmin', 'DataAdapterAdmin', 'DevOpsUser', 'ExpertOpsAdmin', 'ExpertOpsBetaTester', 'ExpertOpsSCMUser', 'ExpertOpsUser', 'ExpertOpsVMUser', 'ISE-Test', 'ISETEST', 'PartnerAdmin', 'SuperAdmin', 'TagAdmin', 'TagUser', 'TripwireForDevOpsAdmin', 'TripwireSystemAdmin', 'AssetAdmin'], 'customer_id': '{customer_id}', 'email': {redaction_data}"
        updated['args'] = None

        dummyRecord = logging.LogRecord(**original)
        expectedRecord = logging.LogRecord(**updated)

        self.assertNotEqual(dummyRecord, expectedRecord)
        instance = LogSanitizer(None, name='foobar_test')
        result = instance.filter(dummyRecord)
        self.maxDiff = None
        self.assertTrue(result)
        self.assertEqual(dummyRecord.msg, expectedRecord.msg)
        self.assertEqual(dummyRecord.args, expectedRecord.args)

    def test_full_log_system(self):
        # this tests the entire Log stack with the filter applied to a given
        # stream

        # data stream to capture the log data
        log_buffer = StringIO()
        log_buffer.seek(0)
        log_buffer.truncate()

        # Sample log configuration, taken from Customer Manager with the JSON
        # formatter dropped for easier reading
        log_config = {
            'version': 1,
            'disable_existing_loggers': False,
            'filters': {
                'sanitize': {
                    '()': 'twsaas_common.tw_logging.filter.LogSanitizer',
                    'patterns': [],
                }
            },
            'handlers': {
                'console': {
                    'class': 'logging.StreamHandler',
                    'stream': log_buffer,
                    'filters': ['sanitize'],
                },
                'audit_console': {
                    'class': 'logging.StreamHandler',
                    'stream': log_buffer,
                    'filters': ['sanitize'],
                },
            },
            'loggers': {
                '': {'handlers': ['console'], 'level': 'DEBUG', 'propagate': True}
            },
        }
        logging.config.dictConfig(log_config)

        def check_handler(ch):
            if isinstance(h, logging.StreamHandler):
                self.assertEqual(h.stream, log_buffer)
                self.assertTrue(h.stream is log_buffer)
            else:
                self.assertFalse(True, msg=f'Extraneous Log Handler - {h}')

        for k, h in logging._handlers.items():
            check_handler(h)

        # logger configuration
        logger = logging.getLogger('random.jumping.jacks')
        lhp = logger
        ch_count = 0
        while lhp:
            for lh in lhp.handlers:
                ch_count += 1
                check_handler(lh)
            if lhp.parent and lhp.parent != lhp:
                lhp = lhp.parent
            else:
                lhp = None
        self.assertNotEqual(0, ch_count)

        # send the msg into the logger
        msg = 'Feeble Authorization: SSWS %s'
        args = ("TokenGoesHere",)

        # generate log data
        try:
            logger.info(msg, *args)
        except (TypeError, ValueError) as ex:
            raise Exception(f'Error - {msg} - {args}') from ex

        # access the datastream generated by the logger
        logged_data = log_buffer.getvalue()

        # format the check values
        msg_line = msg % args
        expected_result = msg % ('REDACTED',)

        # verify that the input message is *not* in the datastream
        self.assertNotIn(msg_line, logged_data)
        # verify the expected output message *is* in the datastream
        self.assertIn(expected_result, logged_data)
