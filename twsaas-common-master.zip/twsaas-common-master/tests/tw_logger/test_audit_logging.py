import json
import logging
import unittest

from twsaas_common.tracker import initialize_tracker, reset_tracker
from twsaas_common.tracker.utils import set_request_data_to_storage
from twsaas_common.tw_logging import audit as audit_logging
from twsaas_common.tw_logging.log_formatter import AuditJSONFormatter

try:
    from cStringIO import StringIO
except ImportError:
    from io import StringIO


class LoggerTest(unittest.TestCase):
    def setUp(self):
        self.log_buffer = StringIO()
        tw_handler = logging.StreamHandler(self.log_buffer)
        tw_handler.setFormatter(AuditJSONFormatter())
        self.logger = logging.getLogger('audit')
        self.logger.addHandler(tw_handler)
        self.logger.setLevel(logging.DEBUG)
        self.audit_logger = audit_logging.getAuditLog(extra={})

    def tearDown(self):
        self.log_buffer.seek(0)
        self.log_buffer.truncate()

    def test_log_type_in_audit_log_record(self):
        self.audit_logger.info('Audit Scan Started')
        expected_log_type = '"logType": "audit"'
        self.assertIn(expected_log_type, self.log_buffer.getvalue())

    def test_audit_logging_message_default_using_adapter(self):
        initialize_tracker()
        set_request_data_to_storage()
        self.audit_logger.info('Audit Scan Started')
        json_record = json.loads(self.log_buffer.getvalue())
        expected_fields = {
            'logType',
            'applicationName',
            'tenantId',
            'user',
            'timestamp',
            'resource',
            'resourceType',
            'action',
            'uri',
            'method',
            'statusCode',
            'correlationId',
            'sequenceId',
            'description',
        }
        self.assertTrue(expected_fields.issubset(set(json_record)))
        reset_tracker()

    def test_audit_logging_new_log_level(self):
        initialize_tracker()
        set_request_data_to_storage()
        self.audit_logger.audit('Audit Scan Started')
        json_record = json.loads(self.log_buffer.getvalue())
        expected_fields = {
            'logType',
            'applicationName',
            'tenantId',
            'user',
            'timestamp',
            'resource',
            'resourceType',
            'action',
            'uri',
            'method',
            'statusCode',
            'correlationId',
            'sequenceId',
            'description',
        }
        self.assertTrue(expected_fields.issubset(set(json_record)))
        reset_tracker()

    def test_exc_info_is_logged(self):
        try:
            raise ValueError('something wrong')
        except ValueError:
            self.audit_logger.error('Request failed', exc_info=True)
        json_record = json.loads(self.log_buffer.getvalue())
        self.assertIn('Request failed', json_record['description'])


if __name__ == '__main__':
    unittest.main()
