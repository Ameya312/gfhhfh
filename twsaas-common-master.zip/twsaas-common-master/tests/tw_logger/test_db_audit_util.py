import unittest

import ddt

from twsaas_common.tw_logging.audit import utils


@ddt.ddt
class TestAuditDb(unittest.TestCase):
    @ddt.data(('value', 'foo', 'value', []), ('redacted', 'foo', 'value', ['foo']))
    @ddt.unpack
    def test_value_or_redact(self, expected_result, name, value, redaction):
        self.assertEqual(expected_result, utils.value_or_redact(name, value, redaction))

    def test_get_updated_fields_no_updates(self):
        existing_data = {'foo': 'bar', 'howdy': 'doody', 'key': 'value'}
        # Yes this could be a comprehension;
        # but it's a test so let's be explicit on the outcome
        expected_data = {
            'foo': {'old_value': 'bar', 'new_value': None},
            'howdy': {'old_value': 'doody', 'new_value': None},
            'key': {'old_value': 'value', 'new_value': None},
        }
        self.assertEqual(
            utils.get_updated_fields(existing_data, None, []), expected_data
        )

    def test_get_updated_fields_no_updates_with_redactions(self):
        existing_data = {'foo': 'bar', 'howdy': 'doody', 'key': 'value'}
        # Yes this could be a comprehension;
        # but it's a test so let's be explicit on the outcome
        expected_data = {
            'foo': {'old_value': 'bar', 'new_value': None},
            'howdy': {'old_value': 'redacted', 'new_value': 'redacted'},
            'key': {'old_value': 'value', 'new_value': None},
        }
        self.assertEqual(
            utils.get_updated_fields(existing_data, None, ['howdy']), expected_data
        )

    def test_get_updated_fields_with_updates(self):
        existing_data = {
            'foo': 'bar',
            'howdy': ['pirates', 'pop', 'pumpkins'],
            'key': 'value',
            'feeling': 'mutual',
        }
        updated_data = {
            'foo': 'rab',
            'howdy': ['pirates', 'pop', 'pimples'],
            'key': 'eulav',
        }
        expected_data = {
            'foo': {'old_value': 'bar', 'new_value': 'rab'},
            'howdy': {
                'old_value': ['pirates', 'pop', 'pumpkins'],
                'new_value': ['pirates', 'pop', 'pimples'],
            },
            'key': {'old_value': 'value', 'new_value': 'eulav'},
        }
        self.assertEqual(
            utils.get_updated_fields(existing_data, updated_data, []), expected_data
        )

    def test_get_updated_fields_with_updates_with_redactions(self):
        existing_data = {
            'foo': 'bar',
            'howdy': ['pirates', 'pop', 'pumpkins'],
            'key': 'value',
            'feeling': 'mutual',
        }
        updated_data = {
            'foo': 'rab',
            'howdy': ['pirates', 'pop', 'pimples'],
            'key': 'eulav',
        }
        expected_data = {
            'foo': {'old_value': 'bar', 'new_value': 'rab'},
            'howdy': {'old_value': 'redacted', 'new_value': 'redacted'},
            'key': {'old_value': 'value', 'new_value': 'eulav'},
        }
        self.assertEqual(
            utils.get_updated_fields(existing_data, updated_data, ['howdy']),
            expected_data,
        )
