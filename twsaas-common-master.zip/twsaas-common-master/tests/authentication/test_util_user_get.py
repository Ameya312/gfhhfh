import uuid
from unittest import mock

import twsaas_common.authentication.handlers.core
import twsaas_common.authentication.util.user

from .. import models
from ..django_base import auth_django_settings
from . import base_util_user


class TestUtilUserGetUser(base_util_user.UtilUserTestCase):
    @auth_django_settings(
        twsaas_common.authentication.util.user, base_util_user.SETTINGS_DEFAULT
    )
    def test_nonexistent_user(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        with mock.patch(
            'twsaas_common.authentication.util.user.django_get_user_model'
        ) as mock_get_model:
            user_manager = models.DummyUserManager(str(uuid.uuid4()), user_exists=False)
            mock_get_model.return_value = user_manager
            self.assertIsNone(
                twsaas_common.authentication.util.user.get_user(self.jwt_token['sub'])
            )
            # NOTE: `get_user` makes the UUID field an actual UUID object
            # so it must get promoted as such for the comparison
            self.assertEqual(
                user_manager.get_by_natural_key_args, ((self.jwt_token['sub'],), {})
            )

    @auth_django_settings(
        twsaas_common.authentication.util.user, base_util_user.SETTINGS_DEFAULT
    )
    def test_invalid_value(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        with mock.patch(
            'twsaas_common.authentication.util.user.django_get_user_model'
        ) as mock_get_model:
            user_manager = models.DummyUserManager(str(uuid.uuid4()), user_exists=False)
            mock_get_model.return_value = user_manager
            self.assertIsNone(twsaas_common.authentication.util.user.get_user(False))
            self.assertIsNone(user_manager.get_args)

    @auth_django_settings(
        twsaas_common.authentication.util.user, base_util_user.SETTINGS_DEFAULT
    )
    def test_existing_user(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        with mock.patch(
            'twsaas_common.authentication.util.user.django_get_user_model'
        ) as mock_get_model:
            testing_user = models.FlatStanleyUser(
                username=self.user_data['userid'],
                email=self.user_data['email'],
                active=True,
            )
            user_manager = models.DummyUserManager(testing_user, user_exists=True)
            mock_get_model.return_value = user_manager
            result = twsaas_common.authentication.util.user.get_user(
                self.jwt_token['sub']
            )
            self.assertEqual(result, testing_user)
            # NOTE: `get_user` makes the UUID field an actual UUID object
            # so it must get promoted as such for the comparison
            self.assertEqual(
                user_manager.get_by_natural_key_args,
                ((str(uuid.UUID(self.jwt_token['sub'])),), {}),
            )

    @auth_django_settings(
        twsaas_common.authentication.util.user, base_util_user.SETTINGS_DEFAULT
    )
    def test_existing_user_alternate_username_key(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        with mock.patch(
            'twsaas_common.authentication.util.user.django_get_user_model'
        ) as mock_get_model:
            testing_user = models.FlatStanleyUser(
                username=self.user_data['userid'],
                email=self.user_data['email'],
                active=True,
            )
            user_manager = models.DummyUserManager(testing_user, user_exists=True)
            mock_get_model.return_value = user_manager
            result = twsaas_common.authentication.util.user.get_user(
                self.jwt_token['sub']
            )
            self.assertEqual(result, testing_user)
            # NOTE: `get_user` makes the UUID field an actual UUID object
            # so it must get promoted as such for the comparison
            self.assertEqual(
                user_manager.get_by_natural_key_args,
                ((str(uuid.UUID(self.jwt_token['sub'])),), {}),
            )
