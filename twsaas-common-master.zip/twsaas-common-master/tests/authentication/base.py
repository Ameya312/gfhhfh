import base64
import json
import random

from ..django_base import DjangoTestCase


class TwSaasCommonUserIntegrationTestCase(DjangoTestCase):
    pass


class TwSaasCommonAuthenticationTestCase(DjangoTestCase):
    def __values_from_role_mapping__(self, mapping):
        """
        This really to be used as a static method, but the staticmethod and
        even the classmethod functionality is not available when the method
        gets used below however, there's no better way to instantiate the
        variable as a comprehension is not capable of doing the `append`
        functionality from the dict value data.

        To use properly, ignore the first parameter by passing a value of
        `None`; this is valid since it's not used anyway.

        Note that this method is also scoped to being an internal class
        method so it's not callable outside the class unless explicitly called
        by its fully mangled name (_<class>_<function>).

        This method is intended for the use of instantiating the class
        variable AVAILABLE_TRIPWIRE_ROLES.
        """
        final_list = []
        for value_list in [complex_value for complex_value in mapping.values()]:
            for value in value_list:
                final_list.append(value)
        return list(sorted(set(final_list)))

    TRIPWIRE_ROLES_MAPPING = {
        'SuperUser': ['TripwireSystemAdmin'],
        'ExpertOpsAdmin': ['ExpertOptsAdmin', 'PartnerAdmin'],
        'CustomerAdmin': [
            'CustomerAdmin',
            'ExpertOpsUser',
            'ExpertOpsSCMUser',
            'ExpertOpsVMUser',
        ],
        'SCMCustomerUser': ['ExpertOpsSCMUser'],
        'VMCustomerUser': ['ExpertOpsVMUser'],
    }

    # The below is a little python hack to get the values from the
    # TRIPWIRE_ROLES_MAPPING class variable (cvar) and reduce them to a single
    # set of values without any duplicates. It's easier to go from the mapping
    # to a single list than the versus.
    #
    # Note: `None` is purposefully passed as the first parameter doesn't
    # matter. This is also being initialized at time of class definition, not
    # object instantiation ;)
    AVAILABLE_TRIPWIRE_ROLES = __values_from_role_mapping__(
        None, TRIPWIRE_ROLES_MAPPING
    )

    @classmethod
    def select_random_tripwire_role(cls, count=1):
        return random.choices(cls.AVAILABLE_TRIPWIRE_ROLES, k=count)

    @staticmethod
    def jwt_encode(value):
        return base64.urlsafe_b64encode(value).replace(b'=', b'')

    @classmethod
    def make_encoded_payload(cls, payload, header=None, crypto=None):
        if header is None:
            header = {}
        if crypto is None:
            crypto = 'foobar'

        crypto_segment = cls.jwt_encode(crypto.encode('utf-8'))
        header_segment = cls.jwt_encode(json.dumps(header).encode('utf-8'))
        payload_segment = cls.jwt_encode(json.dumps(payload).encode('utf-8'))

        return header_segment + b'.' + payload_segment + b'.' + crypto_segment
