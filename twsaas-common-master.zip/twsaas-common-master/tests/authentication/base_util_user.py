import copy

from django.contrib.auth import get_user_model as django_get_user_model

from .base import TwSaasCommonAuthenticationTestCase

SETTINGS_DEFAULT = {
    # no real settings;  just fix mypy
    'blah': 'blah'
}

# NOTE: The following uses absolute imports as they may be pulled from different
# module level relative to where stuff actually is. This also contributes to reliability
# and clarity for these settings and the tests that use them.
SETTINGS_WITH_SAVE_USER_MODIFIER = {
    'TW_COMMON_SAVE_USER_MODIFIER': 'tests.authentication.base_util_user.dummy_save_modifier'
}

SETTINGS_WITH_BUILD_USER_MODIFIER = {
    'TW_COMMON_BUILD_USER_PROCESSOR': 'tests.authentication.base_util_user.dummy_build_modifier'
}


def dummy_save_modifier(user_obj):
    user_obj.farewell = True


def dummy_build_modifier(user_data, provided_user_data):
    new_user_data = copy.deepcopy(user_data)
    new_user_data['modified'] = True
    return new_user_data


class UtilUserTestCase(TwSaasCommonAuthenticationTestCase):
    def setUp(self, *args, **kwargs):
        super(UtilUserTestCase, self).setUp(*args, **kwargs)
        self.user_data = self.make_user_dict()
        self.jwt_token = self.make_jwt_payload(self.user_data)
        self.user_model_dict = self.make_user_model_dict(self.user_data)
        self.user_model = django_get_user_model()
