import jwt

from twsaas_common.authentication.test_utils import (
    get_deterministic_uuid,
    get_okta_auth,
)


def test_get_okta_auth():
    auth = get_okta_auth(tenant_id=5, username='user', roles=['test'])
    assert auth.startswith('Bearer ')
    token = auth.split(' ', 1)[1]
    decoded = jwt.decode(token, 'secret', algorithms=['HS256'])
    assert decoded['tenant_id'] == str(get_deterministic_uuid(tenant_id=5))
    assert decoded['username'] == 'user'
    assert decoded['roles'] == ['test']
    assert decoded['iss'] == 'https://login.tripwire.io/oauth2/default'


def test_get_okta_auth_tenant_uuid():
    auth = get_okta_auth(tenant_id='e20d7e59-2982-4fac-be8e-08aefa46dca0')
    assert auth.startswith('Bearer ')
    token = auth.split(' ', 1)[1]
    decoded = jwt.decode(token, 'secret', algorithms=['HS256'])
    assert decoded['tenant_id'] == 'e20d7e59-2982-4fac-be8e-08aefa46dca0'
