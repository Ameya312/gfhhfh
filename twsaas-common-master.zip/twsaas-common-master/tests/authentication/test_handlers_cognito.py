import importlib
import unittest
from unittest import mock

from rest_framework import exceptions

import twsaas_common.authentication.handlers.cognito

from .base import TwSaasCommonAuthenticationTestCase

try:
    from django.test import override_settings

    enable_django_testing = True
except ImportError:
    enable_django_testing = False


def cognito_handler(payload):
    return 'oops'


def jwt_decoder(payload):
    return payload


def auth_django_settings(fn):
    """
    Decorator for the default Django Settings Required for
    the Authentication Unit Tests
    """
    # Auth Requires a certain configuration by default.
    # The Auth Tests will change these values as needed.
    SETTINGS_DICT = {
        'FLAG_OIDC_TOKENS': 'oidc',
        'FLAG_COGNITO_TOKENS': 'cognito',
        'FLAGS': {
            'oidc': False,  # Disabled for testing
            'cognito': False,  # Disabled for testing
        },
        'COGNITO_USER_POOL_ID': 'bar',
        'OIDC_BASE_URL': 'https://d34db.33f',
        'AWS_REGION': 'us-west-2',
        'JWT_COGNITO_USER_PROCESSOR': None,
        'JWT_OIDC_USER_PROCESSOR': None,
        'JWT_PAYLOAD_PROCESSOR': None,
    }

    def wrapper(*args, **kwargs):
        # If Django is available then override the settings with the
        # default settings required for the Auth functionality
        if enable_django_testing:
            with override_settings(**SETTINGS_DICT):
                # Reimport the module to ensure the expected default
                # settings are in place as the tests validate some
                # of the default settings to ensure changes are
                # happening as expected
                importlib.reload(twsaas_common.authentication.handlers.core)
                return fn(*args, **kwargs)
        else:
            # If the decorator is attached to a class method
            # then call the class's `skipTest` method
            if args and isinstance(args[0], unittest.TestCase):
                test_case = args[0]
                return test_case.skipTest("Django not available")
            else:
                # otherwise, just raise SkipTest directly
                raise unittest.SkipTest("Django not available")

    return wrapper


class HandlerBase(TwSaasCommonAuthenticationTestCase):
    def check_django_availability(self):
        if not enable_django_testing:
            self.skipTest('Django Settings Override Not Available')

        try:
            # imported just to check if it's available; so make flake8 ignore it
            from django.conf import settings  # noqa
        except ImportError:
            self.skipTest('Django Settings Not Available')


class TestHandlerCognito(HandlerBase):
    @auth_django_settings
    def test_idp_initiate_auth_failure(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        faked_django_settings = {'APP_CLIENT_ID': 'D34DB33F'}
        with override_settings(**faked_django_settings):
            importlib.reload(twsaas_common.authentication.handlers.cognito)
            with mock.patch(
                'twsaas_common.authentication.handlers.cognito.client.initiate_auth'
            ) as mock_boto3:
                mock_boto3.side_effect = Exception('fools errand')
                base_module = twsaas_common.authentication.handlers.cognito
                with self.assertRaises(exceptions.AuthenticationFailed):
                    base_module.idp_initiate_auth('foo', 'bar')

    def test_idp_initiate_auth_success(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        user_data = self.make_user_dict()
        jwt_token = self.make_jwt_payload(user_data)
        encoded_payload = self.make_encoded_payload(jwt_token)

        faked_django_settings = {'APP_CLIENT_ID': 'D34DB33F'}
        with override_settings(**faked_django_settings):
            importlib.reload(twsaas_common.authentication.handlers.cognito)
            with mock.patch(
                'twsaas_common.authentication.handlers.cognito.jwt_decode_handler'
            ) as mock_jwt:
                mock_jwt.return_value = jwt_token
                with mock.patch(
                    'twsaas_common.authentication.handlers.cognito.client.initiate_auth'
                ) as mock_boto3:
                    mock_boto3.return_value = {
                        'AuthenticationResult': {'AccessToken': encoded_payload}
                    }
                    with mock.patch(
                        'twsaas_common.authentication.handlers.cognito.authenticate_jwt_credentials'
                    ) as mock_authenticate:
                        mock_authenticate.return_value = jwt_token
                        base_module = twsaas_common.authentication.handlers.cognito
                        result = base_module.idp_initiate_auth('foo', 'bar')
                        self.assertEqual(result, (jwt_token, None))

    def test_basic_auth(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        user_data = self.make_user_dict()
        jwt_token = self.make_jwt_payload(user_data)
        encoded_payload = self.make_encoded_payload(jwt_token)

        faked_django_settings = {'APP_CLIENT_ID': 'D34DB33F'}
        with override_settings(**faked_django_settings):
            importlib.reload(twsaas_common.authentication.handlers.cognito)
            with mock.patch(
                'twsaas_common.authentication.handlers.cognito.jwt_decode_handler'
            ) as mock_jwt:
                mock_jwt.return_value = jwt_token
                with mock.patch(
                    'twsaas_common.authentication.handlers.cognito.client.initiate_auth'
                ) as mock_boto3:
                    mock_boto3.return_value = {
                        'AuthenticationResult': {'AccessToken': encoded_payload}
                    }
                    with mock.patch(
                        'twsaas_common.authentication.handlers.cognito.authenticate_jwt_credentials'
                    ) as mock_authenticate:
                        mock_authenticate.return_value = jwt_token
                        base_module = twsaas_common.authentication.handlers.cognito
                        basic_auth = base_module.BasicAuthCognitoBackend()
                        result = basic_auth.authenticate_credentials('foo', 'bar')
                        self.assertEqual(result, (jwt_token, None))
