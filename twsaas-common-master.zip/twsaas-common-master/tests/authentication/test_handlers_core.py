import importlib

import pytest

from ..django_base import auth_django_settings
from .base import TwSaasCommonAuthenticationTestCase

try:
    from django.test import override_settings
    from django.core.exceptions import ValidationError
    from rest_framework import exceptions

    import twsaas_common.authentication.handlers.core

except ImportError:
    pass


class PayloadProcessorOperation(Exception):
    pass


def payload_processor(payload, user):
    raise PayloadProcessorOperation("Payload Processor Called")


# Auth Requires a certain configuration by default.
# The Auth Tests will change these values as needed.
SETTINGS_DICT = {
    'FLAG_OIDC_TOKENS': 'oidc',
    'FLAG_COGNITO_TOKENS': 'cognito',
    'FLAGS': {
        'oidc': False,  # Disabled for testing
        'cognito': False,  # Disabled for testing
    },
    'COGNITO_USER_POOL_ID': 'bar',
    'OIDC_BASE_URL': 'https://d34db.33f',
    'AWS_REGION': 'us-west-2',
    'JWT_COGNITO_USER_PROCESSOR': None,
    'JWT_OIDC_USER_PROCESSOR': None,
    'JWT_PAYLOAD_PROCESSOR': None,
    'JWT_SKIP_VERIFY': False,
}
SETTINGS_JWT_SKIP_VERIFY = {}
SETTINGS_JWT_SKIP_VERIFY.update(SETTINGS_DICT)
SETTINGS_JWT_SKIP_VERIFY['JWT_SKIP_VERIFY'] = True


class TestAuthenticateCoreUnsupported(TwSaasCommonAuthenticationTestCase):
    @auth_django_settings(None, None)
    def test_unsupported_interface(self):
        with self.assertRaises(ValidationError):
            twsaas_common.authentication.handlers.core.unsupported_interface(None)


class TestAuthenticateJwtCredentials(TwSaasCommonAuthenticationTestCase):
    @auth_django_settings(twsaas_common.authentication.handlers.core, SETTINGS_DICT)
    def test_missing_userid(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        bad_payload = {}

        base_module = twsaas_common.authentication.handlers.core
        with self.assertRaises(exceptions.AuthenticationFailed):
            base_module.authenticate_jwt_credentials(bad_payload)

    @pytest.mark.django_db
    @auth_django_settings(twsaas_common.authentication.handlers.core, SETTINGS_DICT)
    def test_no_handler(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        user_data = self.make_user_dict()
        jwt_token = self.make_jwt_payload(user_data)

        base_module = twsaas_common.authentication.handlers.core
        with self.assertRaises(exceptions.AuthenticationFailed):
            base_module.authenticate_jwt_credentials(jwt_token)

    @pytest.mark.django_db
    @auth_django_settings(
        twsaas_common.authentication.handlers.core, SETTINGS_JWT_SKIP_VERIFY
    )
    def test_handler_with_default_jwt_skip_verify_enabled(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        user_data = self.make_user_dict()
        jwt_token = self.make_jwt_payload(user_data)

        twsaas_common.authentication.handlers.core.AUTH_STATUS_MAPPING['oidc'] = False
        twsaas_common.authentication.handlers.core.AUTH_STATUS_MAPPING[
            'cognito'
        ] = False
        auth_result = twsaas_common.authentication.handlers.core.authenticate_jwt_credentials(
            jwt_token
        )
        self.assertIsNotNone(auth_result)

    @pytest.mark.django_db
    @auth_django_settings(twsaas_common.authentication.handlers.core, SETTINGS_DICT)
    def test_handler_with_default_jwt_skip_verify_disabled(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        user_data = self.make_user_dict()
        jwt_token = self.make_jwt_payload(user_data)

        twsaas_common.authentication.handlers.core.AUTH_STATUS_MAPPING['oidc'] = False
        twsaas_common.authentication.handlers.core.AUTH_STATUS_MAPPING[
            'cognito'
        ] = False
        with self.assertRaises(exceptions.AuthenticationFailed):
            twsaas_common.authentication.handlers.core.authenticate_jwt_credentials(
                jwt_token
            )

    @pytest.mark.django_db
    @auth_django_settings(twsaas_common.authentication.handlers.core, SETTINGS_DICT)
    def test_handler_with_oidc(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        user_data = self.make_user_dict()
        jwt_token = self.make_jwt_payload(user_data)

        twsaas_common.authentication.handlers.core.AUTH_STATUS_MAPPING['oidc'] = True
        auth_result = twsaas_common.authentication.handlers.core.authenticate_jwt_credentials(
            jwt_token
        )
        self.assertIsNotNone(auth_result)

    @pytest.mark.django_db
    @auth_django_settings(twsaas_common.authentication.handlers.core, SETTINGS_DICT)
    def test_handler_with_cognito(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        user_data = self.make_user_dict()
        jwt_token = self.make_jwt_payload(user_data)
        jwt_token['iss'] = 'cognito.me'
        jwt_token['Enabled'] = True
        jwt_token['UserStatus'] = "CONFIRMED"
        twsaas_common.authentication.handlers.core.AUTH_STATUS_MAPPING['cognito'] = True

        auth_result = twsaas_common.authentication.handlers.core.authenticate_jwt_credentials(
            jwt_token
        )
        self.assertIsNotNone(auth_result)

    @pytest.mark.django_db
    @auth_django_settings(twsaas_common.authentication.handlers.core, SETTINGS_DICT)
    def test_handler_with_oidc_with_processor(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        user_data = self.make_user_dict()
        jwt_token = self.make_jwt_payload(user_data)
        faked_django_settings = {
            'FLAG_OIDC_TOKENS': 'oidc',
            'FLAGS': {'oidc': True},
            'JWT_PAYLOAD_PROCESSOR': (
                'tests.authentication.test_handlers_core.payload_processor'
            ),
        }
        with override_settings(**faked_django_settings):
            importlib.reload(twsaas_common.authentication.handlers.core)
            twsaas_common.authentication.handlers.core.AUTH_STATUS_MAPPING[
                'oidc'
            ] = True
            with self.assertRaises(PayloadProcessorOperation):
                twsaas_common.authentication.handlers.core.authenticate_jwt_credentials(
                    jwt_token
                )

    @pytest.mark.django_db
    @auth_django_settings(twsaas_common.authentication.handlers.core, SETTINGS_DICT)
    def test_django_jwt_token_authenticator(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        user_data = self.make_user_dict()
        jwt_token = self.make_jwt_payload(user_data)

        twsaas_common.authentication.handlers.core.AUTH_STATUS_MAPPING['oidc'] = True
        authenticator = (
            twsaas_common.authentication.handlers.core.CustomJSONWebTokenAuthentication()
        )
        auth_result = authenticator.authenticate_credentials(jwt_token)
        self.assertIsNotNone(auth_result)
