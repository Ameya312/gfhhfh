from unittest import TestCase
from unittest.mock import call, patch

from twsaas_common.authentication.oidc import JwkCache

TEST_AUTH_SERVERS = ('https://authserver1.com', 'https://authserver2.com')
TEST_KEYS = {
    TEST_AUTH_SERVERS[0]: [
        {'kid': 'Foo', 'key': 'Foo Dummy'},
        {'kid': 'Bar', 'key': 'Bar Dummy'},
    ],
    TEST_AUTH_SERVERS[1]: [{'kid': 'Baz', 'key': 'Baz Dummy'}],
}


def mock_retrieve_keys(auth_server):
    return TEST_KEYS[auth_server]


class TestJwkCach(TestCase):
    @patch(
        'twsaas_common.authentication.oidc.jwk_cache.retrieve_keys',
        side_effect=mock_retrieve_keys,
    )
    def test_initial_load(self, retrieve_keys):
        cache = JwkCache(TEST_AUTH_SERVERS)
        key = cache.find_key('Foo')
        retrieve_keys.assert_has_calls(
            [call(auth_server) for auth_server in TEST_AUTH_SERVERS]
        )
        self.assertIsNotNone(key)
        self.assertEqual(key['kid'], 'Foo')

    @patch(
        'twsaas_common.authentication.oidc.jwk_cache.retrieve_keys',
        side_effect=mock_retrieve_keys,
    )
    def test_repeated_load(self, retrieve_keys):
        cache = JwkCache(TEST_AUTH_SERVERS)
        key = cache.find_key('Foo')
        retrieve_keys.reset_mock()
        key = cache.find_key('Invalid')
        self.assertIsNone(key)
        retrieve_keys.assert_not_called()
