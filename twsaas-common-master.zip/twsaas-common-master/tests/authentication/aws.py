from botocore.exceptions import ClientError


def make_boto_client_error(operation_name):
    response_dict = {'Error': {'Message': operation_name}}
    return ClientError(response_dict, operation_name)
