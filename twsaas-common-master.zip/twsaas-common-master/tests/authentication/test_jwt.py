import datetime
import importlib
import unittest
from unittest import mock

import jwt as jwt_core

# for importlib.reload() to work, it must be imported directly at some point too
import twsaas_common.authentication.jwt

from .base import TwSaasCommonAuthenticationTestCase

try:
    from django.test import override_settings

    enable_django_testing = True
except ImportError:
    enable_django_testing = False


def auth_django_settings(fn):
    """
    Decorator for the default Django Settings Required for
    the Authentication Unit Tests
    """
    # Auth Requires a certain configuration by default.
    # The Auth Tests will change these values as needed.
    SETTINGS_DICT = {
        'FLAG_OIDC_TOKENS': 'oidc',
        'FLAG_COGNITO_TOKENS': 'cognito',
        'FLAGS': {
            'oidc': False,  # Disabled for testing
            'cognito': False,  # Disabled for testing
        },
        'COGNITO_USER_POOL_ID': 'bar',
        'OIDC_BASE_URL': 'https://d34db.33f',
        'AWS_REGION': 'us-west-2',
    }

    def wrapper(*args, **kwargs):
        # If Django is available then override the settings with the
        # default settings required for the Auth functionality
        if enable_django_testing:
            with override_settings(**SETTINGS_DICT):
                # Reimport the module to ensure the expected default
                # settings are in place as the tests validate some
                # of the default settings to ensure changes are
                # happening as expected
                importlib.reload(twsaas_common.authentication.jwt)
                return fn(*args, **kwargs)
        else:
            # If the decorator is attached to a class method
            # then call the class's `skipTest` method
            if args and isinstance(args[0], unittest.TestCase):
                test_case = args[0]
                return test_case.skipTest("Django not available")
            else:
                # otherwise, just raise SkipTest directly
                raise unittest.SkipTest("Django not available")

    return wrapper


class Kidder(object):
    def __init__(self, secret):
        self.secret = secret

    def to_pem(self):
        return self.secret


class TestUserNameHandler(TwSaasCommonAuthenticationTestCase):
    def test_jwt_user_handler(self):
        user_data = self.make_user_dict()
        jwt_payload = self.make_jwt_payload(user_data)
        self.assertIn('sub', jwt_payload)
        from twsaas_common.authentication import jwt

        self.assertEqual(jwt.jwt_username_handler(jwt_payload), jwt_payload['sub'])


class TestJwtDecodeHandler(TwSaasCommonAuthenticationTestCase):
    def setUp(self, *args, **kwargs):
        super(TestJwtDecodeHandler, self).setUp(*args, **kwargs)
        self.user_data = self.make_user_dict()
        self.jwt_token = self.make_jwt_payload(self.user_data)
        # `kid` is just a key for identifying the key in the cache to use for decrypt
        self.kid = 'foobar'
        self.kidder = Kidder('barfoo')
        self.cognito_url = 'https://cognito-idp.foo.amazonaws.com/bar'

    def tearDown(self, *args, **kwargs):
        super(TestJwtDecodeHandler, self).tearDown(*args, **kwargs)

        # Some of the tests below modify the Cognito and OIDC configuration
        # To keep from spill over between tests, reload the import here so
        # that everything is reset properly
        importlib.reload(twsaas_common.authentication.jwt)

    def check_django_availability(self):
        if not enable_django_testing:
            self.skipTest('Django Settings Override Not Available')

        try:
            # imported just to check if it's available; so make flake8 ignore it
            from django.conf import settings  # noqa
        except ImportError:
            self.skipTest('Django Settings Not Available')

    def make_jwt_payload(self, user_data):
        base_payload = super(TestJwtDecodeHandler, self).make_jwt_payload(user_data)
        base_payload['iss'] = 'oidc.testing'
        return base_payload

    def encode_jwt_payload(self, algorithm, payload, secret=None):
        return jwt_core.encode(
            payload,
            secret if secret else self.kidder.secret,
            algorithm=algorithm,
            headers={'kid': self.kid},
        )

    @auth_django_settings
    def test_instantiate_defaults(self):
        from twsaas_common.authentication import jwt

        handler = jwt.JwtDecodeHandler()
        self.assertEqual(len(handler.jwt_config), 5)
        self.assertTrue(handler.jwt_config['verify'])
        self.assertIsInstance(handler.jwt_config['expiration'], datetime.timedelta)
        self.assertEqual(handler.jwt_config['expiration'].total_seconds(), 300)
        self.assertEqual(handler.jwt_config['leeway'], 0)
        self.assertIsNone(handler.jwt_config['issuer'])
        self.assertEqual(handler.jwt_config['algorithm'], 'RS256')
        self.assertEqual(len(handler.jwk_cache.authorization_servers), 0)

    @auth_django_settings
    def test_instantiate_non_default(self):
        from twsaas_common.authentication import jwt

        new_values = {
            'verify': False,
            'expiration': datetime.timedelta(hours=1),
            'leeway': datetime.timedelta(minutes=10),
            'issuer': __name__,
            'algorithm': 'HS256',
        }
        handler = jwt.JwtDecodeHandler(
            verify=new_values['verify'],
            expiration=new_values['expiration'],
            leeway=new_values['leeway'],
            issuer=new_values['issuer'],
            algorithm=new_values['algorithm'],
        )
        self.assertEqual(handler.jwt_config, new_values)

    @auth_django_settings
    def test_set_jwt_options(self):
        from twsaas_common.authentication import jwt

        new_values = {
            'verify': False,
            'expiration': datetime.timedelta(hours=2),
            'leeway': datetime.timedelta(minutes=20),
            'issuer': __name__,
            'algorithm': 'HS512',
        }
        handler = jwt.JwtDecodeHandler()
        handler.set_jwt_options(
            verify=new_values['verify'],
            expiration=new_values['expiration'],
            leeway=new_values['leeway'],
            issuer=new_values['issuer'],
            algorithm=new_values['algorithm'],
        )
        self.assertEqual(handler.jwt_config, new_values)
        self.assertEqual(len(handler.jwk_cache.authorization_servers), 0)

    @auth_django_settings
    def test_add_authorization_server(self):
        from twsaas_common.authentication import jwt

        handler = jwt.JwtDecodeHandler()
        self.assertEqual(len(handler.jwk_cache.authorization_servers), 0)
        handler.add_authentication_server('foobar')
        self.assertEqual(len(handler.jwk_cache.authorization_servers), 1)
        self.assertEqual(handler.jwk_cache.authorization_servers, ['foobar'])
        handler.add_authentication_server('barfoo')
        self.assertEqual(len(handler.jwk_cache.authorization_servers), 2)
        self.assertEqual(handler.jwk_cache.authorization_servers, ['foobar', 'barfoo'])

    @auth_django_settings
    def test_setup_encryption_algorithm(self):
        from twsaas_common.authentication import jwt

        def verify_algorithm(jwt_handlers, algorithm):
            for handler in jwt_handlers:
                self.assertEqual(handler.jwt_config['algorithm'], algorithm)

        handlers = [jwt.jwt_decode_handler, jwt.jwt_decode_debug_handler]
        # verify original state
        verify_algorithm(handlers, 'RS256')

        # Change both to HS256
        jwt.setup_encryption_algorithm(algorithm='HS256', debug=True, production=True)
        verify_algorithm(handlers, 'HS256')

        # change production-only back to RS256
        jwt.setup_encryption_algorithm(algorithm='RS256', debug=False, production=True)
        self.assertEqual(jwt.jwt_decode_handler.jwt_config['algorithm'], 'RS256')
        self.assertEqual(jwt.jwt_decode_debug_handler.jwt_config['algorithm'], 'HS256')

        # change both to HS256
        jwt.setup_encryption_algorithm(algorithm='HS256', debug=True, production=True)
        verify_algorithm(handlers, 'HS256')

        # change debug only to RS256
        jwt.setup_encryption_algorithm(algorithm='RS256', debug=True, production=False)
        self.assertEqual(jwt.jwt_decode_handler.jwt_config['algorithm'], 'HS256')
        self.assertEqual(jwt.jwt_decode_debug_handler.jwt_config['algorithm'], 'RS256')

        # change both back to RS256
        jwt.setup_encryption_algorithm(algorithm='RS256', debug=True, production=True)
        verify_algorithm(handlers, 'RS256')

    @mock.patch('jwt.get_unverified_header')
    @auth_django_settings
    def test_callable_bad_key(self, mock_header):
        from twsaas_common.authentication import jwt

        mock_header.return_value = {'kid': 'foobar*foobar'}

        handler = jwt.JwtDecodeHandler()
        with self.assertRaises(jwt_core.DecodeError):
            handler(self.jwt_token)

        mock_header.assert_called()

    @mock.patch('jose.jwk.construct')
    @auth_django_settings
    def test_callable_decode_it_all(self, mock_jwk_construct):
        from twsaas_common.authentication import jwt

        # NOTE: fake out jose.jwk.construct b/c it's an HMAC 256
        #   instead of an RSA 256 and the data isn't stored the same.
        #   if a key could be encoded here then that might be a worthwhile
        #   update to use instead of the `Kidder` object above
        mock_jwk_construct.return_value = self.kidder

        handler = jwt.JwtDecodeHandler()
        handler.set_jwt_options(algorithm='HS256')
        handler.jwk_cache.jwt_keys[self.kid] = self.kidder

        payload = {'Batman': 'Bang', 'Joker': 'Pow'}
        encrypted_payload = self.encode_jwt_payload('HS256', payload)
        decrypted_payload = handler(encrypted_payload)
        self.assertEqual(decrypted_payload, payload)

    @auth_django_settings
    def test_interface_production(self):
        from twsaas_common.authentication import jwt

        self.assertIsInstance(jwt.jwt_decode_handler, jwt.JwtDecodeHandler)
        self.assertTrue(jwt.jwt_decode_handler.jwt_config['verify'])
        self.assertEqual(len(jwt.jwt_decode_handler.jwk_cache.authorization_servers), 0)
        auth_servers = ['foo', 'bar', 'foobar', 'barfoo']
        jwt.setup_authorization_servers(
            ['foo', 'bar', 'foobar', 'barfoo'], debug=False, production=True
        )
        self.assertEqual(
            jwt.jwt_decode_handler.jwk_cache.authorization_servers, auth_servers
        )
        jwt.jwt_decode_handler.jwk_cache.authorization_servers = []

    @auth_django_settings
    def test_interface_debug(self):
        from twsaas_common.authentication import jwt

        self.assertIsInstance(jwt.jwt_decode_debug_handler, jwt.JwtDecodeHandler)
        self.assertFalse(jwt.jwt_decode_debug_handler.jwt_config['verify'])
        self.assertEqual(
            len(jwt.jwt_decode_debug_handler.jwk_cache.authorization_servers), 0
        )
        auth_servers = ['foo', 'bar', 'foobar', 'barfoo']
        jwt.setup_authorization_servers(
            ['foo', 'bar', 'foobar', 'barfoo'], debug=True, production=False
        )
        self.assertEqual(
            jwt.jwt_decode_debug_handler.jwk_cache.authorization_servers, auth_servers
        )
        jwt.jwt_decode_debug_handler.jwk_cache.authorization_servers = []

    @auth_django_settings
    def test_interface_setup_authorization_servers(self):
        from twsaas_common.authentication import jwt

        auth_servers = ['foo', 'bar', 'foobar', 'barfoo']
        self.assertEqual(len(jwt.jwt_decode_handler.jwk_cache.authorization_servers), 0)
        self.assertEqual(
            len(jwt.jwt_decode_debug_handler.jwk_cache.authorization_servers), 0
        )
        jwt.setup_authorization_servers(
            ['foo', 'bar', 'foobar', 'barfoo'], debug=False, production=False
        )
        self.assertEqual(len(jwt.jwt_decode_handler.jwk_cache.authorization_servers), 0)
        self.assertEqual(
            len(jwt.jwt_decode_debug_handler.jwk_cache.authorization_servers), 0
        )
        jwt.setup_authorization_servers(
            ['foo', 'bar', 'foobar', 'barfoo'], debug=True, production=True
        )
        self.assertEqual(
            jwt.jwt_decode_handler.jwk_cache.authorization_servers, auth_servers
        )
        self.assertEqual(
            jwt.jwt_decode_debug_handler.jwk_cache.authorization_servers, auth_servers
        )
        jwt.jwt_decode_handler.jwk_cache.authorization_servers = []
        jwt.jwt_decode_debug_handler.jwk_cache.authorization_servers = []

    @auth_django_settings
    def test_django_autoconfigure_all_disabled(self):
        # Auto-Skip if modules not available
        self.check_django_availability()
        active_settings = twsaas_common.authentication.jwt.get_django_settings()
        self.assertFalse(active_settings['oidc_enabled'])
        self.assertFalse(active_settings['cognito_enabled'])
        self.assertEqual(active_settings['jwk_cache'], [])
        self.assertEqual(active_settings['add_auth_server_calls'], 0)

        importlib.reload(twsaas_common.authentication.jwt)
        active_settings = twsaas_common.authentication.jwt.get_django_settings()
        self.assertFalse(active_settings['oidc_enabled'])
        self.assertFalse(active_settings['cognito_enabled'])
        self.assertEqual(active_settings['jwk_cache'], [])
        self.assertEqual(active_settings['add_auth_server_calls'], 0)

    @auth_django_settings
    def test_django_autoconfigure_cognito_configured_disabled_no_oidc(self):
        # Auto-Skip if modules not available
        self.check_django_availability()
        active_settings = twsaas_common.authentication.jwt.get_django_settings()
        self.assertEqual(active_settings['jwk_cache'], [])
        self.assertFalse(active_settings['oidc_enabled'])
        self.assertFalse(active_settings['cognito_enabled'])
        self.assertEqual(active_settings['add_auth_server_calls'], 0)

        faked_django_settings = {
            'FLAG_COGNITO_TOKENS': 'cognito',
            'FLAGS': {'cognito': False},
            'AWS_REGION': 'foo',
            'COGNITO_USER_POOL_ID': 'bar',
        }
        with override_settings(**faked_django_settings):
            importlib.reload(twsaas_common.authentication.jwt)
            active_settings = twsaas_common.authentication.jwt.get_django_settings()
            self.assertFalse(active_settings['oidc_enabled'])
            self.assertFalse(active_settings['cognito_enabled'])
            self.assertEqual(active_settings['jwk_cache'], [])
            self.assertEqual(active_settings['add_auth_server_calls'], 0)

    @auth_django_settings
    def test_django_autoconfigure_oidc_configured_disabled_no_aws(self):
        # Auto-Skip if modules not available
        self.check_django_availability()
        active_settings = twsaas_common.authentication.jwt.get_django_settings()
        self.assertFalse(active_settings['oidc_enabled'])
        self.assertFalse(active_settings['cognito_enabled'])
        self.assertEqual(active_settings['jwk_cache'], [])
        self.assertEqual(active_settings['add_auth_server_calls'], 0)

        faked_django_settings = {
            'FLAG_OIDC_TOKENS': 'oidc',
            'FLAGS': {'oidc': False},
            'OIDC_BASE_URL': 'https://d34db.33f',
        }
        with override_settings(**faked_django_settings):
            importlib.reload(twsaas_common.authentication.jwt)
            active_settings = twsaas_common.authentication.jwt.get_django_settings()
            self.assertFalse(active_settings['oidc_enabled'])
            self.assertFalse(active_settings['cognito_enabled'])
            self.assertEqual(active_settings['jwk_cache'], [])
            self.assertEqual(active_settings['add_auth_server_calls'], 0)

    @auth_django_settings
    def test_django_autoconfigure_cognito_configured_enabled_no_oidc(self):
        # Auto-Skip if modules not available
        self.check_django_availability()
        active_settings = twsaas_common.authentication.jwt.get_django_settings()
        self.assertFalse(active_settings['oidc_enabled'])
        self.assertFalse(active_settings['cognito_enabled'])
        self.assertEqual(active_settings['jwk_cache'], [])
        self.assertEqual(active_settings['add_auth_server_calls'], 0)

        faked_django_settings = {
            'FLAG_COGNITO_TOKENS': 'cognito',
            'FLAGS': {'cognito': True},
            'AWS_REGION': 'foo',
            'COGNITO_USER_POOL_ID': 'bar',
        }
        expected_list = [self.cognito_url]
        with mock.patch(
            'twsaas_common.authentication.jwt.settings.django_settings_enabled', True
        ):
            with mock.patch(
                'twsaas_common.authentication.jwt.settings.django_settings_enable_congnito',
                True,
            ):
                with override_settings(**faked_django_settings):
                    importlib.reload(twsaas_common.authentication.jwt)
                    active_settings = (
                        twsaas_common.authentication.jwt.get_django_settings()
                    )
                    self.assertTrue(active_settings['enabled'])
                    self.assertFalse(active_settings['oidc_enabled'])
                    self.assertTrue(active_settings['cognito_enabled'])
                    self.assertEqual(active_settings['jwk_cache'], expected_list)
                    self.assertEqual(active_settings['add_auth_server_calls'], 1)

    @auth_django_settings
    def test_django_autoconfigure_oidc_configured_enabled_no_aws(self):
        # Auto-Skip if modules not available
        self.check_django_availability()
        active_settings = twsaas_common.authentication.jwt.get_django_settings()
        self.assertFalse(active_settings['oidc_enabled'])
        self.assertFalse(active_settings['cognito_enabled'])
        self.assertEqual(active_settings['jwk_cache'], [])
        self.assertEqual(active_settings['add_auth_server_calls'], 0)

        my_oidc_url = 'https://d34db.33f'
        faked_django_settings = {
            'FLAG_OIDC_TOKENS': 'oidc',
            'FLAGS': {'oidc': True},
            'OIDC_BASE_URL': my_oidc_url,
        }
        expected_list = [my_oidc_url]
        with mock.patch(
            'twsaas_common.authentication.jwt.settings.django_settings_enabled', True
        ):
            with mock.patch(
                'twsaas_common.authentication.jwt.settings.django_settings_enable_oidc',
                True,
            ):
                with override_settings(**faked_django_settings):
                    importlib.reload(twsaas_common.authentication.jwt)
                    active_settings = (
                        twsaas_common.authentication.jwt.get_django_settings()
                    )
                    self.assertTrue(active_settings['enabled'])
                    self.assertTrue(active_settings['oidc_enabled'])
                    self.assertFalse(active_settings['cognito_enabled'])
                    self.assertEqual(active_settings['jwk_cache'], expected_list)
                    self.assertEqual(active_settings['add_auth_server_calls'], 1)

    @auth_django_settings
    def test_django_autoconfigure_oidc_configured_enabled_all(self):
        # Auto-Skip if modules not available
        self.check_django_availability()
        active_settings = twsaas_common.authentication.jwt.get_django_settings()
        self.assertFalse(active_settings['oidc_enabled'])
        self.assertFalse(active_settings['cognito_enabled'])
        self.assertEqual(active_settings['jwk_cache'], [])
        self.assertEqual(active_settings['add_auth_server_calls'], 0)

        my_oidc_url = 'https://d34db.33f'
        faked_django_settings = {
            'FLAG_OIDC_TOKENS': 'oidc',
            'FLAG_COGNITO_TOKENS': 'cognito',
            'FLAGS': {'oidc': True, 'cognito': True},
            'OIDC_BASE_URL': my_oidc_url,
            'AWS_REGION': 'foo',
            'COGNITO_USER_POOL_ID': 'bar',
        }
        expected_list = [self.cognito_url, my_oidc_url]
        with mock.patch(
            'twsaas_common.authentication.jwt.settings.django_settings_enabled', True
        ):
            with mock.patch(
                'twsaas_common.authentication.jwt.settings.django_settings_enable_oidc',
                True,
            ):
                with mock.patch(
                    'twsaas_common.authentication.jwt.settings.django_settings_enable_congnito',
                    True,
                ):
                    with override_settings(**faked_django_settings):
                        importlib.reload(twsaas_common.authentication.jwt)
                        active_settings = (
                            twsaas_common.authentication.jwt.get_django_settings()
                        )
                        self.assertTrue(active_settings['enabled'])
                        self.assertTrue(active_settings['oidc_enabled'])
                        self.assertTrue(active_settings['cognito_enabled'])
                        self.assertEqual(active_settings['jwk_cache'], expected_list)
                        self.assertEqual(active_settings['add_auth_server_calls'], 1)
