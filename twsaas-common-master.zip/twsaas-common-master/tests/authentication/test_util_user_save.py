import copy
import uuid
from unittest import mock

import pytest

import twsaas_common.authentication.handlers.core
import twsaas_common.authentication.util.user

from .. import models
from ..django_base import auth_django_settings
from . import base_util_user


class TestUtilUserSaveUser(base_util_user.UtilUserTestCase):
    @pytest.mark.django_db
    @auth_django_settings(
        twsaas_common.authentication.util.user, base_util_user.SETTINGS_DEFAULT
    )
    def test_nonexistent_user(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        with mock.patch(
            'twsaas_common.authentication.util.user.django_get_user_model'
        ) as mock_get_model:
            user_manager = models.DummyUserManager(
                str(uuid.uuid4()), user_exists=False, integrity_error=True
            )
            mock_get_model.return_value = user_manager
            with self.assertRaises(models.DummyUserManager.DoesNotExist):
                twsaas_common.authentication.util.user.save_user(
                    self.user_data['userid'], self.user_data
                )

    @pytest.mark.django_db
    @auth_django_settings(
        twsaas_common.authentication.util.user, base_util_user.SETTINGS_DEFAULT
    )
    def test_existent_user(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        with mock.patch(
            'twsaas_common.authentication.util.user.django_get_user_model'
        ) as mock_get_model:
            testing_user = models.FlatStanleyUser(
                username=self.user_data['userid'],
                email=self.user_data['email'],
                active=True,
            )
            user_manager = models.DummyUserManager(
                testing_user, user_exists=True, integrity_error=True
            )
            mock_get_model.return_value = user_manager
            result = twsaas_common.authentication.util.user.save_user(
                self.user_data['userid'], self.user_data
            )
            self.assertEqual(result, testing_user)

    @pytest.mark.django_db
    @auth_django_settings(
        twsaas_common.authentication.util.user, base_util_user.SETTINGS_DEFAULT
    )
    def test_success_no_save_modifier_no_groups(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        with mock.patch(
            'twsaas_common.authentication.util.user.django_get_user_model'
        ) as mock_get_model:
            testing_user = models.FlatStanleyUser(
                username=self.user_data['userid'],
                email=self.user_data['email'],
                active=True,
            )
            user_manager = models.DummyUserManager(
                testing_user, user_exists=True, integrity_error=False
            )
            mock_get_model.return_value = user_manager
            # to verify the user dictionary does not get modified
            self.assertNotIn('groups', self.user_data)
            result = twsaas_common.authentication.util.user.save_user(
                self.user_data['userid'], self.user_data
            )
            # get_user should not be called at all
            self.assertIsNone(user_manager.get_args)
            self.assertEquals(user_manager.create_args, ((), self.user_model_dict))
            self.assertEqual(result, testing_user)

    @pytest.mark.django_db
    @auth_django_settings(
        twsaas_common.authentication.util.user, base_util_user.SETTINGS_DEFAULT
    )
    def test_success_no_save_modifier_with_groups(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        with mock.patch(
            'twsaas_common.authentication.util.user.django_get_user_model'
        ) as mock_get_model:
            testing_user = models.FlatStanleyUser(
                username=self.user_data['userid'],
                email=self.user_data['email'],
                active=True,
            )
            user_manager = models.DummyUserManager(
                testing_user, user_exists=True, integrity_error=False
            )
            mock_get_model.return_value = user_manager
            # to verify the user dictionary does not get modified
            user_data = copy.deepcopy(self.user_data)
            user_data['groups'] = ['russian_roulette', 'black jack']
            result = twsaas_common.authentication.util.user.save_user(
                self.user_data['userid'], user_data
            )
            # get_user should not be called at all
            self.assertIsNone(user_manager.get_args)
            self.assertEquals(user_manager.create_args, ((), self.user_model_dict))
            self.assertEqual(result, testing_user)

    @pytest.mark.django_db
    @auth_django_settings(
        twsaas_common.authentication.util.user,
        base_util_user.SETTINGS_WITH_SAVE_USER_MODIFIER,
    )
    def test_success_with_save_modifier(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        with mock.patch(
            'twsaas_common.authentication.util.user.django_get_user_model'
        ) as mock_get_model:
            testing_user = models.FlatStanleyUser(
                username=self.user_data['userid'],
                email=self.user_data['email'],
                active=True,
            )
            user_manager = models.DummyUserManager(
                testing_user, user_exists=True, integrity_error=False
            )
            mock_get_model.return_value = user_manager
            # to verify the user dictionary does not get modified
            result = twsaas_common.authentication.util.user.save_user(
                self.user_data['userid'], self.user_data
            )
            # get_user should not be called at all
            self.assertIsNone(user_manager.get_args)
            self.assertEquals(user_manager.create_args, ((), self.user_model_dict))
            self.assertEqual(result, testing_user)
            self.assertTrue(hasattr(testing_user, 'farewell'))
            self.assertTrue(testing_user.farewell)
