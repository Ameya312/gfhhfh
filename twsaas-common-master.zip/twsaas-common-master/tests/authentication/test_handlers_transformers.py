from twsaas_common.authentication.handlers.transformers import base, cognito, oidc

from .base_util_user import UtilUserTestCase


class TestHandlerTransformersPayloadTransformer(UtilUserTestCase):
    def test_payload_transformer_initializer(self):
        auth_source = 'foobar'

        payload_transformer = base.PayloadTransformer(
            auth_source, self.user_data['userid']
        )
        self.assertEqual(payload_transformer.auth_source, auth_source)
        self.assertEqual(payload_transformer.userid, self.user_data['userid'])
        self.assertEqual(payload_transformer.roles, [])
        self.assertEqual(payload_transformer.groups, [])
        self.assertEqual(payload_transformer.status, "")
        self.assertFalse(payload_transformer.active)
        self.assertEqual(payload_transformer.user_attributes, {})
        self.assertEqual(payload_transformer.payload, {})

        expected_result = {
            'auth_source': auth_source,
            'userid': self.user_data['userid'],
            'groups': [],
            'status': "",
            'active': False,
            'user_attributes': {},
            'payload': {},
        }
        transformed_payload = payload_transformer.transform()
        self.assertIsInstance(transformed_payload, dict)
        self.assertEqual(transformed_payload, expected_result)

    def test_payload_transformer_initializer_with_payload(self):
        auth_source = 'foobar'
        payload = 'f34rb0t2000'

        payload_transformer = base.PayloadTransformer(
            auth_source, self.user_data['userid'], payload=payload
        )
        self.assertEqual(payload_transformer.auth_source, auth_source)
        self.assertEqual(payload_transformer.userid, self.user_data['userid'])
        self.assertEqual(payload_transformer.roles, [])
        self.assertEqual(payload_transformer.groups, [])
        self.assertEqual(payload_transformer.status, "")
        self.assertFalse(payload_transformer.active)
        self.assertEqual(payload_transformer.user_attributes, {})
        self.assertEqual(payload_transformer.payload, payload)

        expected_result = {
            'auth_source': auth_source,
            'userid': self.user_data['userid'],
            'groups': [],
            'status': "",
            'active': False,
            'user_attributes': {},
            'payload': payload,
        }
        transformed_payload = payload_transformer.transform()
        self.assertIsInstance(transformed_payload, dict)
        self.assertEqual(transformed_payload, expected_result)

    def test_default_transform(self):
        payload_data = {'ignore': 'me', 'foo': 'bar', 'b33f': 'd34d'}

        transformed_payload = base.transform_default(
            self.user_data['userid'], payload_data
        )
        expected_result = {
            'auth_source': "BypassService",
            'userid': self.user_data['userid'],
            'groups': [],
            'status': "CONFIRMED",
            'active': True,
            'user_attributes': {'email': 'nobody@nowhere.net'},
            'payload': {},
        }
        self.assertIsInstance(transformed_payload, dict)
        self.assertEqual(transformed_payload, expected_result)

    def test_cognito_transform_defaults(self):
        transformed_payload = cognito.transform_token(self.user_data['userid'], {})
        expected_result = {
            'auth_source': "Cognito",
            'userid': self.user_data['userid'],
            'groups': list(),
            'status': "INVALID",
            'active': False,
            'user_attributes': {},
            'payload': {},
        }
        self.assertIsInstance(transformed_payload, dict)
        self.assertEqual(transformed_payload, expected_result)

    def test_cognito_transform_with_payload(self):
        payload = {
            'cognito:groups': 'training',
            'Enabled': True,
            'UserStatus': 'TENDING',
            'UserAttributes': [{'Name': 'foo', 'Value': 'bar'}],
        }
        transformed_payload = cognito.transform_token(self.user_data['userid'], payload)
        expected_result = {
            'auth_source': "Cognito",
            'userid': self.user_data['userid'],
            'groups': 'training',
            'status': "TENDING",
            'active': True,
            'user_attributes': {'foo': 'bar'},
            'payload': payload,
        }
        self.assertIsInstance(transformed_payload, dict)
        self.assertEqual(transformed_payload, expected_result)

    def test_oidc_transform_default(self):
        expected_result = {
            'auth_source': 'OIDC',
            'userid': self.user_data['userid'],
            'groups': list(),
            'status': "CONFIRMED",
            'active': True,
            'user_attributes': {},
            'payload': {},
        }
        transformed_payload = oidc.transform_token(self.user_data['userid'], {})
        self.assertEqual(transformed_payload, expected_result)

    def test_oidc_transform_with_payload(self):
        oidc_roles = 'roles'
        payload = {'roles': oidc_roles}
        expected_result = {
            'auth_source': 'OIDC',
            'userid': self.user_data['userid'],
            'groups': oidc_roles,
            'status': "CONFIRMED",
            'active': True,
            'user_attributes': {},
            'payload': payload,
        }
        transformed_payload = oidc.transform_token(self.user_data['userid'], payload)
        self.assertEqual(transformed_payload, expected_result)
