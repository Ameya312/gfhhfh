import twsaas_common.authentication.util.user

from ..django_base import auth_django_settings
from . import base_util_user


class TestUtilUserSaveTransform(base_util_user.UtilUserTestCase):
    @auth_django_settings(
        twsaas_common.authentication.util.user, base_util_user.SETTINGS_DEFAULT
    )
    def test_base_transform(self):
        user_data, groups = twsaas_common.authentication.util.user.transform_for_save(
            {}
        )
        self.assertIsNone(groups)
        self.assertEqual(user_data, {})

    @auth_django_settings(
        twsaas_common.authentication.util.user, base_util_user.SETTINGS_DEFAULT
    )
    def test_basic_transform(self):
        input_data = {'userid': self.user_data['userid'], 'active': True}
        expected_data = {'username': self.user_data['userid']}
        user_data, groups = twsaas_common.authentication.util.user.transform_for_save(
            input_data
        )
        self.assertIsNone(groups)
        self.assertEqual(user_data, expected_data)

    @auth_django_settings(
        twsaas_common.authentication.util.user, base_util_user.SETTINGS_DEFAULT
    )
    def test_basic_transform_with_extra_data(self):
        input_data = {'userid': self.user_data['userid'], 'active': True, 'foo': 'bar'}
        expected_data = {'username': self.user_data['userid']}
        user_data, groups = twsaas_common.authentication.util.user.transform_for_save(
            input_data
        )
        self.assertIsNone(groups)
        self.assertEqual(user_data, expected_data)

    @auth_django_settings(
        twsaas_common.authentication.util.user, base_util_user.SETTINGS_DEFAULT
    )
    def test_basic_transform_with_groups(self):
        group_data = [
            "Mary had a little lamb",
            "it's fleece was white as snow",
            "and every where that Mary went",
            "the lamb was sure to go",
        ]
        input_data = {
            'userid': self.user_data['userid'],
            'active': True,
            'foo': 'bar',
            'groups': group_data,
        }
        expected_data = {'username': self.user_data['userid']}
        user_data, groups = twsaas_common.authentication.util.user.transform_for_save(
            input_data
        )
        self.assertEqual(groups, group_data)
        self.assertEqual(user_data, expected_data)

    @auth_django_settings(
        twsaas_common.authentication.util.user,
        base_util_user.SETTINGS_WITH_BUILD_USER_MODIFIER,
    )
    def test_build_user_modifier(self):
        # Auto-Skip if modules not available
        self.check_django_availability()

        input_data = {'userid': self.user_data['userid'], 'active': True}
        expected_data = {'username': self.user_data['userid'], 'modified': True}
        user_data, groups = twsaas_common.authentication.util.user.transform_for_save(
            input_data
        )
        self.assertIsNone(groups)
        self.assertEqual(user_data, expected_data)
