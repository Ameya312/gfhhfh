from django.core.exceptions import ImproperlyConfigured

import twsaas_common.authentication.handlers.core
from twsaas_common.authentication import util

from ..django_base import auth_django_settings
from .base import TwSaasCommonAuthenticationTestCase


class TestLocalImport(TwSaasCommonAuthenticationTestCase):
    @auth_django_settings(twsaas_common.authentication.handlers.core, None)
    def test_successful_import(self):
        import_result = util.managed_local_import_from_string(
            'twsaas_common.authentication.handlers.core.'
            'CustomJSONWebTokenAuthentication'
        )
        self.assertIsNotNone(import_result)
        self.assertEqual(
            import_result,
            twsaas_common.authentication.handlers.core.CustomJSONWebTokenAuthentication,
        )

    @auth_django_settings(twsaas_common.authentication.handlers.core, None)
    def test_successful_none_import(self):
        self.assertIsNone(util.managed_local_import_from_string(None))

    @auth_django_settings(None, None)
    def test_unsuccessful_import(self):
        with self.assertRaises(ImproperlyConfigured):
            util.managed_local_import_from_string(
                'twsaas_common.authentication.handlers.core.Foobar'
            )
