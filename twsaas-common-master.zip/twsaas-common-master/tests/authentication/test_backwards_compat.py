import unittest
import warnings

from .base import TwSaasCommonAuthenticationTestCase


class TestJwkCacheBackwardsCompat(TwSaasCommonAuthenticationTestCase):
    def test_old_import_location(self):
        from twsaas_common.oidc import JwkCache

        # To satisfy flake8's F401 error:
        dir(JwkCache)

    @unittest.expectedFailure
    def test_old_import_location_generates_deprecation(self):
        unittest.SkipTest("DecrecationWarning not being generated as expected")
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always", DeprecationWarning)
            import twsaas_common.oidc

            self.assertEqual(1, len(w))
            self.assertIsInstance(w[-1].category, DeprecationWarning)
            self.assertIn('deprecated', str(w[-1].message))

            # To satisfy flake8's F401 error:
            dir(twsaas_common.oidc)
