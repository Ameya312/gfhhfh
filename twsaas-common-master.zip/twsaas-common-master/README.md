# twsaas-common
Common handy shared libraries that can be used across services.

## To Use In Your Service

See the [asset-service](https://github.scm.tripwire.com/tw-devops/asset-service)
repository for an example of how to include twsaas-common in your service.

1. Add the following source into your Pipfile:
    ```makefile
    [[source]]
    url = "https://artifactory.scm.tripwire.com/artifactory/api/pypi/pypi-saas-local/simple"
    verify_ssl = true
    name = "artifactory"
    ```

1. Create a ~/.netrc file with your artifactory credentials
    ```
    machine artifactory.scm.tripwire.com
    login tss_username
    password artifactory_api_key
    ```

1. You can now add twsaas-common to your Pipfile via `pipenv install twsaas-common==1.0.0+2019.05.30.084034.1afbbf6`

## Optional dependencies

The various sub-packages under `twsaas_common` are fairly unrelated, and have different dependencies.  As such, by default twsaas-common declares no dependencies of its own.  To ensure you install the correct dependencies for the sub-package(s) that you are using, twsaas-common declares a set of extras.

For example, the following Pipfile will not pull in any dependencies:

```
[packages]
twsaas_common = "*"
```

To ensure that you install the dependencies you need, use the `extras` keyword.  For example, this Pipfile would install Django and boto3 as required by the `messaging` sub-package:

```
[packages]
twsaas_common = {extras = ["messaging"], version = "*"}
```

The `twsaas_common` package currently has the following sub-packages:

Package                                                | Extra        | description                                    | Django Status
-------------------------------------------------------|--------------|------------------------------------------------|--------------
[messaging](twsaas_common/messaging/README.md)         | messaging    | Helpers for working with AWS SNS/SQS messages. | Required
[oidc](twsaas_common/oidc/README.md)                   | oidc         | Helpers for working with OpenID Connect        | Optional
[auth_handler](twsaas_common/authentication/README.md) | auth_handler | Helpers for working with Authentication        | Required
[oidc_django](twsaas_common/oidc/README.md)            | oidc_django  | Helpers under Django for OIDC                  | Required

See the individual packages' README.md files for more information about them.

## Using twsaas_common with Django

Adding `twsaas_common` to the list of installed applications (`INSTALLED_APPS`) can be problematic, and should be avoided unless absolutely necessary.
`twsaas_common` is *NOT* a Django Application itself, but does provide some Django tooling as an optional feature for Django Applications.
Putting `twsaas_common` into the list of installed applications will cause the module's unit tests to be picked up and run; if the default configuration
conflicts with configurations required by the unit tests then unexpected failures may occur beyond you're applications control.

## Running pre-commit hooks

This repository has pre-commit hooks to auto-format and lint all files.

1. [Install the pre-commit tool](https://pre-commit.com/#install)
1. Run `pre-commit install`


## Running Unit Tests

1. `make setup-env` to install your python venv.
1. `make test`


## Deploy to Artifactory

Artifacts are deployed to [pypi-saas-local](https://artifactory.scm.tripwire.com/artifactory/webapp/#/artifacts/browse/tree/Properties/pypi-saas-local)

You must be logged in to Artifactory to read this repository.

To deploy:

1. `make deploy`
