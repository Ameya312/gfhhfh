import os

from setuptools import setup

name = "twsaas-common"
version = "1.2.0"

# release file is written by iwmake
# add release info to version for artifactory versioning
try:
    with open('twsaas_common/RELEASE.txt') as h:
        version += '+' + h.read().strip()
except IOError:
    pass


packages = []
data = []
for dirpathstr, dirnames, filenames in os.walk('twsaas_common', followlinks=True):
    dirpath = dirpathstr.split('/')
    if '__init__.py' in filenames:
        packages.append('.'.join(dirpath))
    dirpathstr = '/'.join(dirpath[1:])
    if dirpathstr:
        dirpathstr += '/'
    for filename in filenames:
        if filename.split('.')[-1] not in (
            'py',
            'pyc',
            'pyo',
            'mo',
            'md',
        ) and not filename.endswith('~'):
            data.append(dirpathstr + filename)

setup(
    name=name,
    version=version,
    author="Tripwire Inc",
    author_email="support@tripwire.com",
    description="Tripwire SaaS Common Utilities",
    license="Closed",
    url="http://www.tripwire.com/",
    packages=packages,
    package_data={
        'twsaas_common': data,
        # includes the RELEASE.txt file with the package
        '': ['*.txt'],
    },
    extras_require={
        'messaging': ['Django', 'boto3'],
        'oidc': ['PyJWT', 'python-jose', 'requests'],
        'oidc_django': ['Django', 'boto3'],
        'auth_handler': ['Django', 'boto3', 'rest_framework'],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Topic :: Utilities",
        "License :: Other/Proprietary License",
    ],
)
